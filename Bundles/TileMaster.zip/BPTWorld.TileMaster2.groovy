/**
 *  ****************  Tile Master 2 Parent ****************
 *
 *  Design Usage:
 *  Create a tile with multiple devices and customization options.
 *
 *  Copyright 2019-2022 Bryan Turcotte (@bptworld)
 *
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 *
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  2.1.6 - 05/06/22 - Bundle Manager
 *  2.1.5 - 04/27/20 - Cosmetic changes
 *  2.1.4 - 04/25/20 - Cosmetic changes
 *  2.1.3 - 03/15/20 - Added option field - cloudToken
 *  2.1.2 - 03/14/20 - Added Maker API setup to parent app
 *  2.1.1 - 03/02/20 - Removed status color options from parent app
 *  2.1.0 - 02/26/20 - Added support for Tile to Tile copying
 *  ---
 *  1.0.0 - 02/16/19 - Initially started working on this concept but never released.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
	state.version = null
}

definition(
    name:"Tile Master 2",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Create a tile with multiple devices and customization options.",
    category: "Convenience",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "https://raw.githubusercontent.com/bptworld/Hubitat/master/Apps/Tile%20Master/TM2-parent.groovy",
)

preferences {
    page name: "mainPage", title: "", install: true, uninstall: true
    page name: "iconOptions", title: "", install: false, uninstall: true, nextPage: "mainPage"
    page name: "urlOptions", title: "", install: false, uninstall: true, nextPage: "mainPage"
} 

def installed() {
    log.debug "Installed with settings: ${settings}"
    initialize()
}

def updated() {
    log.debug "Updated with settings: ${settings}"
    unsubscribe()
    initialize()
}

def initialize() {
    log.info "There are ${childApps.size()} child apps"
    childApps.each {child ->
    	log.info "Child app: ${child.label}"
    }
    sendIconList()
}

def mainPage() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
    	installCheck()
		if(state.appInstalled == 'COMPLETE'){
			section("Instructions:", hideable: true, hidden: true) {
				paragraph "<b>Information</b>"
				paragraph "Create a tile with multiple devices and customization options."
			}
            
            section(getFormat("header-green", "${getImage("Blank")}"+" Global Config")) {
                if(iconName || iconURL) {
                    href "iconOptions", title:"${getImage("optionsGreen")} Select Icons", description:"Click here for Options"
                } else {
                    href "iconOptions", title:"${getImage("optionsRed")} Select Icons", description:"Click here for Options"
                }

                if(hubIP && makerID && accessToken) {
                    href "urlOptions", title:"${getImage("optionsGreen")} Maker API Setup", description:"Click here for Options"
                } else {
                    href "urlOptions", title:"${getImage("optionsRed")} Maker API Setup", description:"Click here for Options"
                }
            }
            
			section(getFormat("header-green", "${getImage("Blank")}"+" Child Apps")) {
                paragraph "If you want to use Icons with your devices - Complete the 'Select Icons' section<br>If you want to be able to control devices - Complete the 'Maker API' section"
				app(name: "anyOpenApp", appName: "Tile Master 2 Child", namespace: "BPTWorld", title: "<b>Add a new 'Tile Master 2' child</b>", multiple: true)
			}
            
			section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
       			label title: "Enter a name for parent app (optional)", required: false
                input "logEnable", "bool", defaultValue: "false", title: "Enable Debug Logging", description: "Enable extra logging for debugging."
            }
            display2()
        }
    }
}

// ********** Start - URL Options **********

def urlOptions() {
    dynamicPage(name: "urlOptions", title: "", install:false, uninstall:false) {
        display()
    
        section(getFormat("header-green", "${getImage("Blank")}"+" Maker API Config")) {
            input "hubIP", "text", title: "Hub IP Address<br><small>(ie. 192.168.86.81)</small>", submitOnChange:true
            input "cloudToken", "password", title: "Hub Cloud Token (optional)<br><small>(ie. found after the /api/ kdj3-dj3-dkfjj3-kdjfak4-akdjdke55)</small>", submitOnChange:true

            input "makerID", "text", title: "Maker API App Number<br><small>(ie. 104)</small>", width:6, submitOnChange:true
            input "accessToken", "password", title: "Maker API Access Token<br><small>(ie. kajdkfj-3kd8-dkjf-akdjkdf)</small>", width:6, submitOnChange:true
        }
    }
}

// ********** End - URL Options **********

// ********** Start - Icon Options **********

def iconOptions() {
    dynamicPage(name: "iconOptions", title: "", install:false, uninstall:false) {
        display()
        section(getFormat("header-green", "${getImage("Blank")}"+" Icon Options")) {}
        section("Instructions:", hideable: true, hidden: true) {
			paragraph "<b>Exchange your device status with Icons!</b>"
            
            instruct =  "- It is highly recommended to use a url shortener, like <a href='https://bitly.com/' target='_blank'>bitly.com</a></small> "
            instruct += "This will save on character counts.<br>"
            instruct += "- Remember to add icons for both values (ie. on and off, open and closed)<br>"
            instruct += "- Add as many icons as you like, you can use different icons for different devices!<br>"
            instruct += "- All icon URL addresses must include 'http://'<br>"
            instruct += "- When deleting icons, only the Name is required (Must be exact)"
            
            paragraph "${instruct}"
		}
        section() {
            input "iconName", "text", title: "Icon Name (ie. Green Check Mark)", submitOnChange:true
            input "iconURL", "text", title: "Icon URL (ie. http://bit.ly/2m0udns) <small>* It is highly recommended to use a url shortener, like <a href='https://bitly.com/' target='_blank'>bitly.com</a></small>", submitOnChange:true
            input "addIcon", "button", title: "Add Icon", width: 4
            input "delIcon", "button", title: "Delete Icon", width: 4
            input "delList", "button", title: "Delete All Icons", width: 4
            if(state.message != null) paragraph "<b>${state.message}</b>"
            if(state.deleteAllIcons) {
                input "delListYes", "button", title: "Yes", width: 6
                input "delListNo", "button", title: "No", width: 6
            }
            paragraph "<hr>"
            if(state.iconList == null || state.iconList == "") state.iconList = "Empty"
            paragraph "<b>Icon List</b><br>${state.iconList}"
        }
    }
}

def addIcon() {
    if(logEnable) log.debug "******************* addIcon - Start *******************"
    if(logEnable) log.debug "In addIcon (${state.version})"

    if(state.theList == null) state.theList = []
    newIcon = "${iconName};${iconURL}"
    checkForMatch(iconName)
    if(!match) {
        state.theList << newIcon   
        state.theList = state.theList.sort()
        state.message = "New Icon has been added"
    } else {
        state.message = "Icon was found with the same name, please use a different name for each icon"
    }
    if(logEnable) log.debug "******************* addIcon - End *******************"
    buildIconList()
}

def buildIconList() {
    if(logEnable) log.debug "******************* buildIconList - Start *******************"
    if(logEnable) log.debug "In buildIconList (${state.version})"
    if(state.theList) {           
	    def listView = "${state.theList}".split(", ")
		theList = "<table>"
    	listView.each { item -> 
            def (iconName,iconAdd) = item.split(";")
            iconName = iconName.replace("[","")
            iconAdd = iconAdd.replace("]","")
            log.debug "working on theList: ${iconName} - ${iconAdd}"
            theList += "<tr><td>${iconName}</td><td> - </td><td><img src='$iconAdd' height=30></td></tr>"
        }
        theList += "</table>"
        state.iconList = "${theList}"
    }
    if(logEnable) log.debug "******************* buildIconList - End *******************"
    sendIconList()
}

def sendIconList() {
    if(logEnable) log.debug "******************* sendIconList - Start *******************"
    if(logEnable) log.debug "In sendIconList (${state.version}) - Sending List"
    childApps.each {child -> child.masterListHandler(state.theList)}
    if(logEnable) log.debug "In sendIconList (${state.version}) - List Sent!"
    if(logEnable) log.debug "******************* sendIconList - End *******************"
}

def checkForMatch(iconName) {
    if(logEnable) log.debug "In checkForMatch (${state.version})"
    match = false
    listCount = state.theList.size()
    for(x=0;x < listCount;x++) {
        if(logEnable) log.debug "In checkForMatch - Looking for ${iconName}"
        theItem = state.theList[x]
        def (listName, listAdd) = theItem.split(";")
        if(listName == iconName) {
            if(logEnable) log.debug "In checkForMatch - Match! - listName: ${listName} vs iconName: ${iconName}"
            match = true
        } else {
            if(logEnable) log.debug "In checkForMatch - Didin't Match! - listName: ${listName} vs iconName: ${iconName}"
        }
    }
    return match
}

def delIcon() {
    if(logEnable) log.debug "******************* delIcon - Start *******************"
    if(logEnable) log.debug "In delIcon (${state.version})"
    match = false
    listCount = state.theList.size()
    for(x=0;x < listCount;x++) {
        if(logEnable) log.debug "In delIcon - Looking for ${iconName}"
        theItem = state.theList[x]
        def (listName, listAdd) = theItem.split(";")
        if(listName == iconName) {
            if(logEnable) log.debug "In delIcon - Match! - listName: ${listName} vs iconName: ${iconName}"
            state.theList.remove(state.theList[x])
            listCount = state.theList.size()
            match = true
        } else {
            if(logEnable) log.debug "In delIcon - Didin't Match! - listName: ${listName} vs iconName: ${iconName}"
        }
    }
    if(match) {
        state.message = "Icon ${iconName} has been deleted"
    } else {
        state.message = "Icon ${iconName} was not found, Icon not deleted"
    }
    if(logEnable) log.debug "******************* delIcon - End *******************"
    buildIconList()
}

def delAllIcons() {
    if(logEnable) log.debug "In delList (${state.version})"
    state.iconList = null
    state.theList = null
    state.message = "All Icons have been deleted"
    state.deleteAllIcons = false
}

// ********** End - Icon Options **********

def appButtonHandler(buttonPressed) {
    state.whichButton = buttonPressed
    if(logEnable) log.debug "In appButtonHandler (${state.version}) - Button Pressed: ${state.whichButton}"
    if(state.whichButton == "addIcon"){
        addIcon()
    }
    if(state.whichButton == "delIcon"){
        delIcon()
    }
    if(state.whichButton == "delList"){
        state.message = "Are you sure you want to DELETE all icons? This can not be undone."
        state.deleteAllIcons = true
    }
    if(state.whichButton == "delListYes"){
        delAllIcons()
    }
    if(state.whichButton == "delListNo"){
        state.message = "Delete All Icons was cancelled"
        state.deleteAllIcons = false
    }
}

def installCheck(){
    display()
	state.appInstalled = app.getInstallationState() 
	if(state.appInstalled != 'COMPLETE'){
		section{paragraph "Please hit 'Done' to install '${app.label}' parent app "}
  	}
  	else{
    	log.info "Parent Installed OK"
  	}
}

def getTileSettings(fromTile,toTile) {        // copy from tile to tile
    if(logEnable) log.debug "In getTileSettings - fromTile: ${fromTile}"
    // Get the settings from 'other' child
    childApps.each { child ->
        if(logEnable) log.debug "In getTileSettings - Checking Child: ${child.id} vs fromTile: ${fromTile}"
        if(child.id == fromTile) {
            if(logEnable) log.debug "In getTileSettings - MATCH! (${fromTile})"
            theSettings = child.sendChildSettings()
            if(logEnable) log.debug "In getTileSettings - theSettings: (${theSettings})"
        }
	} 
    // Send the settings to 'new' child
    childApps.each { child ->
        if(logEnable) log.debug "In getTileSettings - Checking Child: ${child.id} vs toTile: ${toTile}"
        if(child.id == toTile) {
            if(logEnable) log.debug "In getTileSettings - MATCH! (${toTile})"
		    child.doTheTileCopy(theSettings)
        }
	} 
}
