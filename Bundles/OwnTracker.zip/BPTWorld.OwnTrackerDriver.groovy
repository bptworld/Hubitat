/*
 * Virtual Mobile Presence for Owntracks - based on original work by Austin Pritchett/ajpri
 * 'OwnTracks Virtual Mobile Presence Driver' driver by Brian Wilson (@brianwilson) - Version 1.1.3.5
 *
 * This version for use with OwnTracker - @bptworld
*/

import java.text.SimpleDateFormat

metadata {
    definition (name: "OwnTracker Driver", namespace: "BPTWorld", author: "Bryan Turcotte", importUrl: "") {
        capability "Switch"
        capability "Refresh"
        capability "Presence Sensor"
        capability "Sensor"
        capability "Battery"

        attribute "ssid", "string"
        attribute "bssid", "string"
        attribute "battery", "number"
        attribute "batteryStatus", "string"
        attribute "region", "string"
        attribute "user", "string"
        attribute "lat", "number"
        attribute "lon", "number"
        attribute "lastUpdated", "string"
        attribute "fName", "string"
        attribute "gMapSingleImage", "string"
        attribute "gMapMultiImage", "string"
        attribute "gStreet", "string"
        attribute "currentWP", "string"
        attribute "statusTile", "string"
        attribute "historyTile", "string"
        attribute "avatar", "string"
        attribute "avatarSize", "string"
        attribute "lastLogMessage", "string"
        attribute "nearbyPlaces", "string"

        command "arrived"
        command "departed"
        command "statusTileHandler"
    }
	preferences { 
		input name: "region", type: "text", title: "Location/Region to Track", required: true
		input name: "user", type: "text", title: "User to Track", required: true
        input "avatarFontSize", "text", title: "Avatar Font Size", required: true, defaultValue: "15"
        input "historyFontSize", "text", title: "History Font Size", required: true, defaultValue: "15"
        input "historyHourType", "bool", title: "Time Selection for History Tile (Off for 24h, On for 12h)", required: false, defaultValue: false
    }
}

def parse(String description) {
}

def on() {
	sendEvent(name: "switch", value: "on")
	sendEvent(name: "presence", value: "present")
}

def off() {
	sendEvent(name: "switch", value: "off")
	sendEvent(name: "presence", value: "not present")
}

def arrived() {
	on()
}

def departed () {
	off()
}

def installed () {
    // nothing
}

def refresh() {
    updated()
}

def updated() {
	state.clear()
	sendEvent(name: "user", value: "${user}") 
	sendEvent(name: "region", value: "${region}")
    sendEvent(name: "fName", value: "${fName}")
    statusTileHandler()
}

def statusTileHandler(data) {
    if(logEnable) log.trace "In statusTileHandler - Making the Avatar Tile - data: $data"
    avat = device.currentValue("avatar")
    name = device.currentValue("fName")
    place = device.currentValue('currentWP')
    address = device.currentValue('gStreet')
    bLevel = device.currentValue('battery')
    bCharge = device.currentValue('batteryStatus')
    bSsid = device.currentValue('ssid')
    lUpdated = device.currentValue('lastUpdated')
    avatSize = device.currentValue('avatarSize')
    avatFontSize = device.currentValue('avatarFontSize')
    //sFont = avatFontSize.toInteger() / 1.25

    tileMap = "<div style='overflow:auto;height:90%'><table width='100%'>"
    tileMap += "<tr><td width='100%'><b>${name}"
    tileMap += "<tr><td><p style='font-size:${avatFontSize}px'>"
    tileMap += "At: ${place}<br>"
    tileMap += "Address: ${address}<br>"
    tileMap += "Phone Lvl: ${bLevel} - ${bCharge} - ${bSsid}<br>"
    tileMap += "<small>Since: ${lUpdated}</small>"   
    tileMap += "</b></p></table></div>"

    tileDevice1Count = tileMap.length()
    if(tileDevice1Count <= 1024) {
        if(logEnable) log.debug "tileMap - has ${tileDevice1Count} Characters<br>${tileMap}"
    } else {
        log.warn "In statusTileHandler - Too many characters to display on Dashboard (${tileDevice1Count})"
    }
    sendEvent(name: "statusTile", value: tileMap, isStateChange: true)
}
