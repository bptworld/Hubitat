/**
 *  **************** OwnTracker App  ****************
 *
 *  Design Usage:
 *  Map your location with OwnTracks! Requires OwnTracks Presence and a free Google Maps API account.
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  0.0.1 - 09/11/22 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "OwnTracker"
	state.version = "0.0.1"
    subscribe(location, "getVersionInfo", updateVersionHandler)
}

def syncVersion(){
    setVersion()
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "OwnTracker",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Map your location with OwnTracks! Requires OwnTracks Presence and a free Google Maps API account.",
    category: "Convenience",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
    page(name: "waypointOptions", title: "", install: false, uninstall: true, nextPage: "pageConfig")
    page(name: "userOptions", title: "", install: false, uninstall: true, nextPage: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Map your location with OwnTracks! Requires OwnTracks Presence and a free Google Maps API account."
            paragraph "This app is an add-on to 'OwnTracks Presence'. Be sure to have OwnTracks working before moving on to OwnTracker."
		}
        
        section(getFormat("header-green", "${getImage("Blank")}"+" User Options")) {  
            href "userOptions", title:"User Options", description:"Click here to set up your options!"
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Waypoint Options")) {
            href "waypointOptions", title:"Waypoint Options", description:"Click here to set up your waypoints!"
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Waypoint Mapping Options")) {
            paragraph "Please be sure to enable the Goolge Maps, Geocoding and Places API within the <a href='https://cloud.google.com/cloud-console' target='_blank'>Google Cloud Console</a>"
            input "googleKey", "password", title: "Enter your <a href='https://cloud.google.com/cloud-console' target='_blank'>Google Maps API Key</a>", required:false, submitOnChange:true
            input "mapType", "enum", title: "Select the Single type of map", options: [
                ["r":"roadmap"],
                ["s":"satellite"],
                ["t":"terrain"],
                ["h":"hybrid"]
            ], defaultValue:"r", submitOnChange:true, width:6
            input "mapType2", "enum", title: "Select the Multi type of map", options: [
                ["roadmap":"roadmap"],
                ["satellite":"satellite"],
                ["terrain":"terrain"],
                ["hybrid":"hybrid"]
            ], defaultValue:"roadmap", submitOnChange:true, width:6
            input "mapZoomS", "number", title: "Single - Map zoom level (1 to 20)", range: '1..20', defaultValue:18, submitOnChange:true, width:6
            paragraph "Multi Map auto zooms based on distance between the waypoints", width:6
            if(logEnable) {
                input "getGoogle", "bool", title: "DEBUG: Get Google Maps", defaultValue:false, submitOnChange:true
                if(getGoogle) {
                    otUsers.each { ot ->
                        googleHandler(ot.displayName)
                    }
                    app.updateSetting("getGoogle", [value:"false",type:"bool"])
                }
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Other Options")) {
            input "dateType", "enum", title: "Date format", options: [
                ["12h":"12 Hour"],
                ["24h":"24 Hour"],
            ], defaultValue:"12h", submitOnChange:true, width:6
            input "historyLines", "number", title: "How many lines to show in History (1 to 20)<br><small>* Might display less based on character count</small>", range: '1..20', submitOnChange:true, width:6
            input "historyFontSize", "number", title: "History Font Size (px)", range: '1..24', defaultValue:12, submitOnChange:true
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
                input "buttonClear", "button", title: "Clear Table <small><abbr title='This will delete all data, use with caution. This can not be undone.'><b>- INFO -</b></abbr></small>", width: 4
            }
        }
        display2()
    }
}

def userOptions() {
    dynamicPage(name: "userOptions", title: "", install: false, uninstall:false){
        display()
        section(getFormat("header-green", "${getImage("Blank")}"+" User Options")) {
            paragraph "IMPORTANT: Before selecting any devices, be sure to go into each one and change the driver to 'OwnTracker Driver'"
            input "otUsers", "capability.presenceSensor", title: "Pick the OwnTrack Users to track", multiple:true, submitOnChange:true
            if(otUsers) {
                usersList = []
                otUsers.each { otu ->
                    usersList << otu.displayName
                }                   
                paragraph "- <b>To add or edit</b>, select a User and click the toggle. Then fill in the values below. Press the Add/Edit button<br>- <b>To delete</b>, select a User and click the toggle. Then press the Delete button.<br><small>* Remember to click outside all fields before pressing a button.</small>"        
                input "userName", "enum", title: "User Name", options: usersList, required:false, submitOnChange:true, width:6
                input "findIt", "bool", title: "Enter a Name and then Toggle this switch to 'Find it'", defaultValue:false, submitOnChange:true, width:6
                pIn = getFormat("line")
                paragraph "${pIn}"
                if(findIt) {
                    if(userName) {
                        if(state.userMap == null) state.userMap = [:]
                        userFound = state.userMap.get(userName)
                        if(userFound) {            
                            pieces = userFound.split(":")
                            avatarURL = pieces[0]
                            app.updateSetting("avatarURL", [value:"${avatarURL}",type:"text"])
                            state.uworking = true
                        } else {
                            app.removeSetting("avatarURL")
                            state.uworking = true
                        }
                    } else {
                        state.uworking = false
                    }
                    app.updateSetting("findIt",[value:"false",type:"bool"])
                }

                if(userName) {
                    input "fName", "text", title: "User Friendly Name", required: true
                    getFileList2()
                    paragraph "If you want to use an Avatar on your dashboard, please select it below. File should be in jpg or png format and around 140 x 140 px<br><small>* Avatar only works with local dashboards</small>"
                    input "avatar", "enum", title: "Select an Avatar File", options: fileList2, submitOnChange:true, width:6
                    input "avatarSize", "text", title: "Avatar Size by Percentage", required: true, defaultValue: "75", width:6
                }

                if(state.uworking) {
                    input "buttonUserAdd", "button", title: "Add/Edit Device", width: 4
                    input "buttonUserDel", "button", title: "Delete Device", width: 4
                    paragraph "", width: 4

                    paragraph "<small>* Remember to click outside all fields before pressing a button.</small>"
                    theLine = getFormat("line")
                    paragraph "${theLine}"
                    input "showUserMap", "bool", title: "Show User Map", defaultValue: false, submitOnChange: true
                    if(showUserMap) {
                        if(state.displayUserMap == null) {
                            theUserMap = "No devices are setup"
                        } else {
                            theUserMap = state.displayUserMap
                        }
                        paragraph "${theUserMap}"
                    }
                    theLine = getFormat("line")
                    paragraph "${theLine}"
                    if(logEnable) paragraph "Debug: ${state.userMap}"
                } else {
                    theLine = getFormat("line")
                    paragraph "Please select a user."
                    paragraph "${theLine}"
                }
                
                if(state.displayUserMap && state.userChangesMade) {
                    input "sendUserChanges", "bool", title: "<b>Send changes to devices</b>", defaultValue:false, submitOnChange:true
                    if(sendUserChanges) {
                        otUsers.each { theU ->
                            dName = theU.displayName
                            stuff = state.userMap.get(dName)
                            
                            if(stuff) {
                                def pieces = stuff.split(";")
                                fName = pieces[0]; avat = pieces[1]; avatSize = pieces[2]
                                if(logEnable) log.debug "Sending Stuff - $dName - $fName - $avat - $avatSize"
                                theU.sendEvent(name: "fName", value: fName, displayed: true)
                                theU.sendEvent(name: "avatar", value: "<img src='http://${location.hub.localIP}/local/${avat}' height='${avatSize}%'>", displayed: true)
                                theU.sendEvent(name: "avatarSize", value: avatSize, displayed: true)
                            } else {
                                if(logEnable) log.debug "Sending Stuff - $dName - NO STUFF"
                            }
                        }
                        state.userChangesMade = false
                        app.updateSetting("sendUserChanges",[value:"false",type:"bool"])
                    }
                }
            }
        }
        display2()
    }
}

def waypointOptions() {
    dynamicPage(name: "waypointOptions", title: "", install: false, uninstall:false){
        display()
        section(getFormat("header-green", "${getImage("Blank")}"+" Waypoint List")) {
            paragraph "Click on an existing waypoint to edit/delete or enter in a new waypoint, <i>below</i> the list."
            if(state.waypointMap) {
                state.waypointMap = state.waypointMap.sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
                displayMap =  "<table width=90% align=center><tr><td><b><u>Name</u></b><td><b><u>Longitude</u></b><td><b><u>Latitude</u></b><td><b><u>Radius</u></b>"
                state.waypointMap.each { dm ->
                    theKey = dm.key
                    theValue = dm.value
                    def pieces = theValue.split(":")
                    try {
                        lat = pieces[0].trim(); lon = pieces[1].trim(); rad = pieces[2].trim()
                    } catch (e) {
                        if(logEnable) log.warn "In Make Map - Oops - lat(0): ${lat} - lon(1): ${lon} - rad[2]: ${rad}"
                    }

                    if(rad) rad = rad.replace("]","")
                    displayMap += "<tr><td>" + buttonLink(theKey + "-Gridmap",theKey)
                    displayMap += "<td>${lat}"
                    displayMap += "<td>${lon}"
                    displayMap += "<td>${rad}"
                }                
                displayMap += "</table>"
            } else {
                displayMap = "Empty"
            }

            paragraph "${displayMap}"
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Waypoint Options")) {
            howTo =  "- <b>To add</b>, Fill in all the values below. Then press the Add/Edit button.<br>"
            howTo += "- <b>To edit</b>, Click on a waypoint from the list, edit the info. Then press the Add/Edit button.<br>"
            howTo += "- <b>To delete</b>, Click on a waypoint from the list. Then press the Delete button.<br>"
            howTo += "<small>* Remember to click outside all fields before pressing a button.</small>"
            paragraph "${howTo}"
            
            if(state.clicked) {
                pieces = state.wpStats.split(":")
                lat1 = pieces[0].trim(); lon1 = pieces[1].trim(); rad1 = pieces[2].trim()
                app.updateSetting("wpName", [value:"${state.wpName}",type:"text"])
                app.updateSetting("lat", [value:"${lat1}",type:"number"])
                app.updateSetting("lon", [value:"${lon1}",type:"number"])
                app.updateSetting("rad", [value:"${rad1}",type:"number"])
                state.clicked = false
            }

            input "wpName", "text", title: "Waypoint Name", required:false, submitOnChange:true
            input "lat", "text", title: "Latitude", submitOnChange:true, width:6
            input "lon", "text", title: "Longitude", submitOnChange:true, width:6
            input "rad", "number", title: "Radius", submitOnChange:true, width:6
            paragraph "", width:6

            input "buttonAdd", "button", title: "Add/Edit Device", width: 4
            input "buttonDel", "button", title: "Delete Device", width: 4
            paragraph "", width: 4

            paragraph "<small>* Remember to click outside all fields before pressing a button.</small>"
            theLine = getFormat("line")
            paragraph "${theLine}"

            input "importLife360Places", "bool", title: "Import Life360 Places from file<br><small>* Must have already exported Places from within the Life360 with States app.</small>", defaultValue:false, submitOnChange:true
            if(importLife360Places) {
                app.updateSetting("showMap",[value:"false",type:"bool"])
                pauseExecution(500)
                readFile("life360Places.txt")
                pauseExecution(500)
                app.updateSetting("showMap",[value:"false",type:"bool"])
                app.updateSetting("importLife360Places",[value:"false",type:"bool"])
            }
        }
        display2()
    }
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(otUsers) subscribe(otUsers, "lat", whereAmI) 
        if(otUsers) subscribe(otUsers, "region", regionHandler)
    }
}

def regionHandler(evt) {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(logEnable) log.debug "In regionHandler (${state.version}) - evt: $evt.displayName - evt: $evt.value"
        evtDevice = evt.displayName
        currentWaypoint = null    
        state.howManyUsers = otUsers.size()

        otUsers.each { ot ->
            if(ot.displayName.toString() == evtDevice.toString()) {
                fName = ot.currentValue("fName")
                if(state.waypointMap) {       
                    state.waypointMap.each { wpm ->
                        if(logEnable) log.debug " --------------------  regionHandler - $wpm  --------------------"
                        if(logEnable) log.debug "In regionHandler - working on: $wpm.value"
                        theValues = wpm.value.toString().split(":")
                        def wpLat = new Float (theValues[0])
                        def wpLon = new Float (theValues[1])
                        def wpRadius = new Float (theValues[2])
                        currentWaypoint = wpm.key
                        if(state.prevWaypoint == null) state.prevWaypoint = currentWaypoint
                    }

                    if(currentWaypoint) {
                        ot.sendEvent(name: "currentWP", value: currentWaypoint, displayed: true)
                        if(currentWaypoint == state.prevWaypoint) {
                            if(logEnable) log.debug "In regionHandler - ${evtDevice} is still at waypoint - $currentWaypoint"
                        } else {
                            if(logEnable) log.debug "In regionHandler - ${evtDevice} is at waypoint - $currentWaypoint"
                            state.prevWaypoint = currentWaypoint
                            ot.sendEvent(name: "lon", value: wpLon, displayed: true)
                            ot.sendEvent(name: "lat", value: wpLat, displayed: true)
                        }
                    }
                }
            }
            if(logEnable) log.debug "In regionHandler - Finished - ${evtDevice}"
        }
    }
}

def whereAmI(evt) { 
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(logEnable) log.debug "In whereAmI (${state.version}) - evt: $evt.displayName - evt: $evt.value"
        evtDevice = evt.displayName
        currentWaypoint = null    
        state.howManyUsers = otUsers.size()

        otUsers.each { ot ->
            if(ot.displayName.toString() == evtDevice.toString()) {
                fName = ot.currentValue("fName")
                nLat = new Float (ot.currentValue("lat"))
                nLon = new Float (ot.currentValue("lon"))
                if(logEnable) log.debug "In whereAmI - NEW - ${fName} - nLat: $nLat - nLon: $nLon"

                if(state.waypointMap) {       
                    state.waypointMap.each { wpm ->
                        if(logEnable) log.debug " --------------------  whereAmI - $wpm  --------------------"
                        if(logEnable) log.debug "In whereAmI - working on: $wpm.value"
                        theValues = wpm.value.toString().split(":")
                        def wpLat = new Float (theValues[0])
                        def wpLon = new Float (theValues[1])
                        def wpRadius = new Float (theValues[2])
                        def distanceAway = (haversine(nLat, nLon, wpLat, wpLon)*1000) // in meters 
                        if(distanceAway <= wpRadius) {
                            currentWaypoint = wpm.key
                            if(state.prevWaypoint == null) state.prevWaypoint = currentWaypoint
                        }
                    }

                    if(currentWaypoint) {
                        ot.sendEvent(name: "currentWP", value: currentWaypoint, displayed: true)
                        if(currentWaypoint == state.prevWaypoint) {
                            if(logEnable) log.debug "In whereAmI - ${evtDevice} is still at waypoint - $currentWaypoint"
                        } else {
                            if(logEnable) log.debug "In whereAmI - ${evtDevice} is at waypoint - $currentWaypoint"
                            state.prevWaypoint = currentWaypoint
                            historyHandler(currentWaypoint, fName)
                        }
                    } else {
                        currentWaypoint = "Unknown"
                        ot.sendEvent(name: "currentWP", value: currentWaypoint, displayed: true)
                        if(logEnable) log.debug "In whereAmI - ${evtDevice} - No waypoint matched"
                        if(state.prevLat == null) state.prevLat = nLat
                        if(state.prevLon == null) state.prevLon = nLon

                        def distanceAway = (haversine(state.prevLat, state.prevLon, nLat, nLon)*1000) // in meters 
                        if(distanceAway > 50) {
                            if(logEnable) log.debug "In whereAmI - ${evtDevice} is at a new unknown waypoint"
                            state.prevLat = nLat
                            state.prevLon = nLon
                            historyHandler(currentWaypoint, fName)
                        }
                    }

                    googleHandler(evtDevice, currentWaypoint)
                }
            }
            if(logEnable) log.debug "In whereAmI - Finished - ${evtDevice}"
        }
    }
}

def haversine(lat1, lon1, lat2, lon2) {
    def R = 6372.8    // In kilometers
    def dLat = Math.toRadians(lat2 - lat1)
    def dLon = Math.toRadians(lon2 - lon1)
    lat1 = Math.toRadians(lat1)
    lat2 = Math.toRadians(lat2) 
    def a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2)
    def c = 2 * Math.asin(Math.sqrt(a))
    def d = R * c
    return(d)
}

def googleHandler(theDevice, currentWaypoint) {
    if(logEnable) log.debug "In googleHandler (${state.version}) - $theDevice"
    state.multiLocsMap = []
    markers = ""
    x = 1
    otUsers.each { ot ->
        xName = ot.currentValue("fName")
        xInit = xName.take(1)
        xLat = ot.currentValue("lat")
        xLon = ot.currentValue("lon")
        getColorHandler(x)
        markers += "&markers=color:${theColor}%7Clabel:${xInit}%7C${xLat},${xLon}"        
        locs = "${xLat};${xLon}"
        state.multiLocsMap << locs
        
        if(ot.displayName.toString() == theDevice.toString()) {          
            getGoogleStreetHandler(xLat,xLon)
            theAddress = state.address[0]
            ot.sendEvent(name: "gStreet", value: theAddress, displayed: true)
            if(currentWaypoint == "Unknown") { historyHandler(theAddress, fName) }
            state.address = []

            getGooglePlacesHandler(xLat,xLon)
            if(nearbyPlaces) { ot.sendEvent(name: "nearbyPlaces", value: nearbyPlaces, displayed: true) }
            
            // interactive map
            aSingleMap = "<iframe width=\"100%\" height=\"100%\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\" src=\"https://maps.google.com/maps?q=${xLat},${xLon}&center=${xLat},${xLon}&t=${mapType}&z=${mapZoomS}&ie=UTF8&iwloc=B&output=embed\"></iframe>"

            aSingleMapSize = aSingleMap.size()
            if(logEnable) log.debug "In googleHandler - aSingleMapSize: $aSingleMapSize"
            if(aSingleMap) ot.sendEvent(name: "gMapSingleImage", value: "${aSingleMap}", displayed: true)
            
            getDateTime()
            ot.sendEvent(name: "lastUpdated", value: newDate)
            ot.statusTileHandler("bam")
        }
        x += 1
    }
    
    if(googleKey) {
        if(state.howManyUsers > 1) {
            getCenterFromLocations(state.multiLocsMap)
            gMapMulti = "https://maps.googleapis.com/maps/api/staticmap?center=${state.cLat},${state.cLon}&size=600x450${markers}&maptype=${mapType2}&key=${googleKey}"
            gMapMultiImage = "<img width='100%' src='${gMapMulti}' height='200 width='200'>"
            gMapMultiImageSize = gMapMultiImage.size()
            if(logEnable) log.debug "In googleHandler - gMapMultiImageSize: $gMapMultiImageSize"
            otUsers.each { ot ->
                ot.sendEvent(name: "gMapMultiImage", value: "${gMapMultiImage}", displayed: true)
            }
        } else {
            ot.sendEvent(name: "gMapMultiImage", value: "NA", displayed: true)
        }
    } else {
        log.warn "OwnTracker - This feature requires a Google API Key"
    }
    state.cLat = null
    state.cLon = null
}

def getGoogleStreetHandler(xLat,xLon) {
    state.address = []
    if(googleKey) {
        def params = [
            uri: "https://maps.googleapis.com/maps/api/geocode/json?latlng=${xLat},${xLon}&key=${googleKey}",
            requestContentType: "application/json",
            contentType: "application/json",
            timeout: 120
        ]
        httpGet(params) { resp ->
            def json = resp.data
            for(rec in json.results) {
                address = rec.formatted_address
                //if(logEnable) log.debug "In getGoogleStreetHandler - address: ${address}"
                state.address << address
            }
        }
    } else {
        log.warn "OwnTracker - This feature requires a Google API Key"
    }
}

def getGooglePlacesHandler(xLat,xLon) {
    nearby = []
    nearbyPlaces = ""
    if(googleKey) {
        def params = [
            uri: "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${xLat},${xLon}&radius=40&key=${googleKey}",
            requestContentType: "application/json",
            contentType: "application/json",
            timeout: 120
        ]
        httpGet(params) { resp ->
            def json = resp.data
            for(rec in json.results) {
                name = rec.name
                types = rec.types
                types.each { it ->
                    if(it == "establishment") {
                        //log.warn "In getGooglePlacesHandler - name: ${name} - ${types}"
                        nearby << name
                    }
                }
            }
        }
        if(nearby) {
            aNearby = nearby.sort { a, b -> a.toLowerCase() <=> b.toLowerCase() }
            aNearby.each { n ->
                if(nearbyPlaces == "") {
                    nearbyPlaces = "${n}"
                } else {
                    nearbyPlaces += ", ${n}"
                }
            }
        } else {
            nearbyPlaces = "No places found"
        }
    } else {
        log.warn "OwnTracker - This feature requires a Google API Key"
    }
    return nearbyPlaces
}

def wpMapHander(data) {
    if(logEnable) log.debug "In wpMapHander (${state.version}) - data: ${data}"
    def (theType, newData) = data.split(";")
    if(state.waypointMap == null) state.waypointMap = [:]
    if(theType == "add") {
        if(logEnable) log.debug "In wpMapHander - ADD"
        if(logEnable) log.debug "In wpMapHander - ${wpName} - ${lat}, ${lon} - ${rad}"
        theValue = "${lat}:${lon}:${rad}"
        if(logEnable) log.debug "In wpMapHander - ${wpName} - theValue: ${theValue}"
        state.waypointMap.put(wpName,theValue)
    } else if(theType == "del") {
        if(logEnable) log.debug "In wpMapHander - DELETE"
        state.waypointMap.remove(wpName)
    } else if(theType == "clear") {
        if(logEnable) log.debug "In wpMapHander - CLEAR"
        state.waypointMap = [:]
        state.wpName = null
        state.wpStats = null
        state.clicked = false
    }
    
// ***** Make Map *****    
    //if(logEnable) log.debug "In wpMapHander - Make Map: ${state.waypointMap}"
    if(state.waypointMap) {
        state.waypointMap = state.waypointMap.sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        displayMap =  "<table width=90% align=center><tr><td><b><u>Name</u></b><td><b><u>Longitude</u></b><td><b><u>Latitude</u></b><td><b><u>Radius</u></b>"
        state.waypointMap.each { dm ->
            theKey = dm.key
            theValue = dm.value
            def pieces = theValue.split(":")
            try {
                lat = pieces[0]; lon = pieces[1]; rad = pieces[2]
            } catch (e) {
                if(logEnable) log.warn "In Make Map - Oops - lat(0): ${lat} - lon(1): ${lon} - rad[2]: ${rad}"
            }
                
            if(rad) rad = rad.replace("]","")
            displayMap += "<tr><td>${theKey}<td>${lat}<td>${lon}<td>${rad}"
        }                
        displayMap += "</table>"
    } else {
        displayMap = "Empty"
    }
    state.displayMap = displayMap
    state.waypointMap.put("nothing","stillNothing")
    pauseExecution(500)
    state.waypointMap.remove("nothing")
}

def userMapHander(data) {
    if(logEnable) log.debug "In userMapHander (${state.version}) - data: ${data}"
    def (theType, newData) = data.split(";")
    if(state.userMap == null) state.userMap = [:]
    if(theType == "add") {
        if(logEnable) log.debug "In userMapHander - ADD"
        theValue = "${fName};${avatar};${avatarSize}"
        if(logEnable) log.debug "In userMapHander - ${userName} - theValue: ${theValue}"
        state.userMap.put(userName,theValue)
        state.userChangesMade = true
    } else if(theType == "del") {
        if(logEnable) log.debug "In userMapHander - DELETE"
        state.userMap.remove(userName)
    } else if(theType == "clear") {
        if(logEnable) log.debug "In userMapHander - CLEAR"
        state.userMap = [:]
    }
    
// ***** Make Map *****    
    if(logEnable) log.debug "In userMapHander - Make User Map: ${state.userMap}"
    if(state.userMap) {
        state.userMap = state.userMap.sort { a, b -> a.key.toLowerCase() <=> b.key.toLowerCase() }
        displayUserMap =  "<table width=90% align=center><tr><td><b><u>Device Name</u></b><td><b><u>Friendly</u></b><td><b><u>Avatar</u></b><td><b><u>Avat Size</u></b>"
        state.userMap.each { um ->
            theKey = um.key
            theValue = um.value
            def pieces = theValue.split(";")
            try {
                fName = pieces[0]; avat = pieces[1]; avatSize = pieces[2]
            } catch (e) {
                if(logEnable) log.warn "In Make User Map - Oops - fName(0): ${fName} - avat[1]: ${avat} - avatSize[2]: ${avatSize}"
                if(!avat) avat = "NA"
                if(!avatSize) avatSize = "75"
            }
                
            if(avatSize) avatSize = avatSize.replace("]","")
            displayUserMap += "<tr><td>${theKey}<td>${fName}<td>${avat}<td>${avatSize}"
        }                
        displayUserMap += "</table>"
    } else {
        displayUserMap = "Empty"
    }
    state.displayUserMap = displayUserMap
    state.userMap.put("nothing","stillNothing")
    pauseExecution(500)
    state.userMap.remove("nothing")
}

def appButtonHandler(buttonPressed) {
    if(logEnable) log.debug "--------------------------------------------------------------------------------------------------"
    if(logEnable) log.debug "In appButtonHandler (${state.version}) - Button Pressed: ${buttonPressed}"
    if(buttonPressed.toString().contains("-Gridmap")) {
        if(state.waypointMap == null) state.waypointMap = [:]
        def theName = buttonPressed.replace("-Gridmap","")
        state.wpStats = state.waypointMap.get(theName)
        if(state.wpStats) {
            state.wpName = theName
            state.clicked = true
        } else {
            state.wpName = null
            state.wpStats = null
            state.clicked = false
        }
    } else if(buttonPressed == "buttonDel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        wpMapHander("del;nothing")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(buttonPressed == "buttonAdd") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        wpMapHander("add;nothing")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(buttonPressed == "buttonClear"){
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        wpMapHander("clear;nothing")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(buttonPressed == "resetMaps") {
        state.waypointMap = [:]
    } else if(userName && buttonPressed == "buttonUserDel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        userMapHander("del;nothing")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(userName && buttonPressed == "buttonUserAdd") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        userMapHander("add;nothing")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    }
}

void getCenterFromLocations(stuff) {       
    if(stuff){
        theData = stuff.toString().split(", ")
        theCount = theData.size()
        X = 0.0
        Y = 0.0
        Z = 0.0

        theData.each { data ->
            (la, lo) = data.split(";")
            la = la.replace("[","")
            lo = lo.replace("]","")
            
            lat = la.toDouble() * Math.PI / 180
            lon = lo.toDouble() * Math.PI / 180

            a = Math.cos(lat) * Math.cos(lon)
            b = Math.cos(lat) * Math.sin(lon)
            c = Math.sin(lat)

            X += a
            Y += b
            Z += c
        }

        X /= theCount
        Y /= theCount
        Z /= theCount

        lon = Math.atan2(Y, X)
        hyp = Math.sqrt(X * X + Y * Y)
        lat = Math.atan2(Z, hyp)

        state.cLat = (lat * 180 / Math.PI)
        state.cLon = (lon * 180 / Math.PI)
    }
}

def getColorHandler(x) {
    if(x==1 || x==11) { 
        theColor = "blue"
    } else if(x==2 || x==12) { 
        theColor = "green"
    } else if(x==3 || x==13) { 
        theColor = "orange"
    } else if(x==4 || x==14) { 
        theColor = "yellow"
    } else if(x==5 || x==15) { 
        theColor = "purple"
    } else if(x==6 || x==16) { 
        theColor = "pink"
    } else if(x==7 || x==17) { 
        theColor = "red"
    } else if(x==8 || x==18) { 
        theColor = "white"
    } else if(x==9 || x==19) { 
        theColor = "black"
    } else if(x==10 || x==20) { 
        theColor = "brown"
    }
    return theColor
}

def login() {        // Modified from code by @dman2306
    if(logEnable) log.debug "In login - Checking Hub Security"
    state.cookie = ""
    if(hubSecurity) {
        try{
            httpPost(
                [
                    uri: "http://127.0.0.1:8080",
                    path: "/login",
                    query: 
                    [
                        loginRedirect: "/"
                    ],
                    body:
                    [
                        username: hubUsername,
                        password: hubPassword,
                        submit: "Login"
                    ],
                    textParser: true,
                    ignoreSSLIssues: true
                ]
            )
            { resp ->
                if (resp.data?.text?.contains("The login information you supplied was incorrect.")) {
                    log.warn "Bundle Manager - username/password is incorrect."
                } else {
                    state.cookie = resp?.headers?.'Set-Cookie'?.split(';')?.getAt(0)
                }
            }
        } catch (e) {
            log.error(getExceptionMessageWithLine(e))
        }
    }
}

Boolean getFileList2(){
    login()
    if(logEnable) log.debug "In getFileList2 - Getting list of files"
    uri = "http://${location.hub.localIP}:8080/hub/fileManager/json";
    def params = [
        uri: uri,
        headers: [
            "Cookie": state.cookie,
        ]
    ]
    try {
        fileList2 = []
        httpGet(params) { resp ->
            if (resp != null){
                if(logEnable) log.debug "In getFileList2 - Found the files"
                def json = resp.data
                for (rec in json.files) {
                    fileType = rec.name[-3..-1]
                    if(fileType == "jpg" || fileType == "png") {
                        fileList2 << rec.name
                    }
                }
            } else {
                //
            }
        }
        return fileList2
    } catch (e) {
        log.error(getExceptionMessageWithLine(e))
    }
}

def getDateTime() {
	def date = new Date()
    if(dateType == "12h") {
        newDate=date.format("E hh:mm a")
    } else if(dateType == "24h") {
        newDate=date.format("E HH:mm")
    } 
    return newDate
}

def historyClearData() {
	if(logEnable) log.debug "In historyClearData - Clearing the data"
    currentWaypoint = "-"
    logCharCount = "0"
    state.list = []	
	historyLog = "Waiting for Data..."
    sendEvent(name: "history", value: historyLog, displayed: true)
    sendEvent(name: "numOfCharacters", value: logCharCount, displayed: true)
    sendEvent(name: "lastLogMessage", value: currentWaypoint, displayed: true)
}

def historyHandler(currentWaypoint, fName) {
    if(currentWaypoint) {
        if(currentWaypoint == "Unknown") {
            if(logEnable) log.trace "In historyHandler - Nothing to report (No Data)"
        } else {   
            try {
                otUsers.each { ot ->
                    theName = ot.currentValue("fName")
                    if(theName.toString() == fName.toString()) {
                        getDateTime()
                        if(state."${theName}" == null) state."${theName}" = []

                        last = "${newDate} - ${fName} - ${currentWaypoint}"
                        state."${theName}".add(0,last)  

                        if(state."${theName}") {
                            listSize = state."${theName}".size()
                        } else {
                            listSize = 0
                        }

                        int intNumOfLines = historyLines.toInteger()
                        if (listSize > intNumOfLines) state."${theName}".removeAt(intNumOfLines)
                        String result = state."${theName}".join(";")
                        def lines = result.split(";")

                        theData = "<div style='overflow:auto;height:90%'><table style='text-align:left;font-size:${historyFontSize}px'><tr><td>"

                        for (i=0;i<intNumOfLines && i<listSize;i++) {
                            combined = theData.length() + lines[i].length()
                            if(combined < 1006) {
                                theData += "${lines[i]}<br>"
                            }
                        }

                        theData += "</table></div>"
                        if(logEnable) log.debug "theData - ${theData.replace("<","!")}"       

                        dataCharCount = theData.length()
                        if(dataCharCount <= 1024) {
                            if(logEnable) log.debug "In historyHandler - theData - ${dataCharCount} Characters"
                        } else {
                            theData = "Too many characters to display on Dashboard (${dataCharCount})"
                        }

                        ot.sendEvent(name: "historyTile", value: theData, displayed: true)
                        ot.sendEvent(name: "lastLogMessage", value: currentWaypoint, displayed: true)
                    }
                }
            }
            catch(e) {
                log.warn "In historyHandler - Something went wrong"
                log.error(getExceptionMessageWithLine(e))
            }
        }
    }
}

String readFile(fName){
    if(logEnable) log.debug "In readFile (${state.version}) - ${fName}"
    login()
    try {
        uri = "http://${location.hub.localIP}:8080/local/${fName}"
        def params = [
            uri: uri,
            contentType: "text/html; charset=UTF-8",
            headers: [
                "Cookie": state.cookie
            ]
        ]

        httpGet(params) { resp ->
            if(resp!= null) {
                def theD = resp.getData()
                theData = theD.toString().split(", ")
                dSize = theData.size()
                if(logEnable) log.debug "In readFile  - dSize: ${dSize}"               
                if(dSize == 0 || theD == "[]\n") {
                    if(logEnable) log.debug "In readFile - There is no data to process"
                } else {
                    if(theData) {
                        if(state.waypointMap == null) state.waypointMap = [:]
                        theData.each { it ->
                            (tKey, tValue) = it.replace("[","").replace("]","").split(":")
                            tKey = tKey.replace("'","")
                            (lat, lon, rad) = tValue.replace("[","").replace("]","").split(";")
                            int theRad = rad.toDouble()
                            theValue = "${lat}:${lon}:${theRad}"
                            state.waypointMap.put(tKey,theValue)
                        }
                        data = "nothing;nothing"
                        wpMapHander(data)
                    }
                }
            } else {
                if(logEnable) log.debug "In readFile - There is no data to process"
            }
        }
    } catch (e) {
        log.warn "File doesn't exist - ${fName}"
        log.error(getExceptionMessageWithLine(e))
    }
}

String buttonLink(String btnName, String linkText, color = "#1A77C9", font = 15) {
    "<div class='form-group'><input type='hidden' name='${btnName}.type' value='button'></div><div><div class='submitOnChange' onclick='buttonClick(this)' style='color:$color;cursor:pointer;font-size:${font}px'> $linkText </div></div><input type='hidden' name='settings[$btnName]' value=''>"
}
