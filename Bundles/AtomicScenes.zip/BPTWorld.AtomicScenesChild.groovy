/**
 *  **************** Atomic Scenes Child App  ****************
 *
 *  Design Usage:
 *  Scenes on steroids!
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  0.0.2 - 06/29/22 - Fixed Cog sorting
 *  0.0.1 - 06/28/22 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Atomic Scenes"
	state.version = "0.0.2"
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Atomic Scenes Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Scenes on steroids",
    category: "Convenience",
	parent: "BPTWorld:Atomic Scenes",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
    page name: "notificationOptions", title: "", install: false, uninstall: false, nextPage: "pageConfig"
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Scenes on steroids!"
		}
        section(getFormat("header-green", "${getImage("Blank")}"+" Virtual Device")) {
            createDeviceSection("Atomic Scenes Driver")
        }
        section() { paragraph "Note: The device selected above will be used to turn this scene on and off." }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Scene Options")) {
            input "masterDimmers", "capability.switchLevel", title: "Master List of Dimmers Needed in this Scene <small><abbr title='Only devices selected here can be used below. This can be edited at anytime.'><b>- INFO -</b></abbr></small>", required:false, multiple:true, submitOnChange:true
            masterList = masterDimmers.toString().replace("[","").replace("]","").split(",")
            paragraph "- <b>To add or edit</b>, select a device and fill in the values below. Then press the Add/Edit button<br>- <b>To delete</b>, select a device. Then press the Delete button.<br><small>* Remember to click outside all fields before pressing a button.</small>"
            if(state.working) {
                paragraph "<b>$dimmerToSet</b>", width:6
                input "orderNumber", "number", title: "Order", submitOnChange:true, width:6
            } else {
                input "dimmerToSet", "enum", title: "Select dimmer to set options", required:false, options:masterList, submitOnChange:true, width:6
                input "orderNumber", "number", title: "Order", submitOnChange:true, width:6
            }

            if(dimmerToSet && state.theDimmerMap && !state.working) {
                app.removeSetting("orderNumber")
                app.removeSetting("dimmerSetLevel")
                app.removeSetting("dimmerColorTemp")
                app.removeSetting("dimmerColor")
                app.removeSetting("dimmerTemp")
                dimmerFound = state.theDimmerMap.get(dimmerToSet)
                if(dimmerFound) {
                    state.working = true               
                    pieces = dimmerFound.split(":")
                    theOrder = pieces[0]; theLevel = pieces[1]; theTempType = pieces[2]; theTemp = pieces[3]; theColor = pieces[4]
                    app.updateSetting("orderNumber", theOrder)
                    app.updateSetting("dimmerSetLevel", theLevel)
                    app.updateSetting("dimmerColorTemp", [value:"${theTempType}",type:"bool"])
                    app.updateSetting("dimmerTemp", theTemp)
                    app.updateSetting("dimmerColor", theColor)
                } else {
                    state.working = true
                }
            }
                       
            input "dimmerSetLevel", "number", title: "On Level (1 to 99 - Leave blank to keep the Current Level)", required:false, multiple:false, range: '1..99', submitOnChange:true
            input "dimmerColorTemp", "bool", title: "Use Color (off) or Temperature (on)", submitOnChange:true
            if(dimmerColorTemp) {
                input "dimmerTemp", "number", title: "Color Temperature", submitOnChange:true
                app.removeSetting("dimmerColor")
                app.removeSetting("useCustomColors")
            } else {
                useCustomColorsHandler()
                input "dimmerColor", "enum", title: "Color (leave blank for no change)", required:false, multiple:false, options: theColors, submitOnChange:true
                app.removeSetting("dimmerTemp")
            }
            
            // *** Start Mode Map ***
            input "buttonCancel", "button", title: "Cancel", width: 3
            input "buttonAdd", "button", title: "Add/Edit Mode", width: 3
            input "buttonDel", "button", title: "Delete Mode", width: 3
            input "buttonClear", "button", title: "Clear Table <small><abbr title='This will delete all data, use with caution. This can not be undone.'><b>- INFO -</b></abbr></small>", width: 3
            //input "refreshMap", "bool", title: "Refresh the Map", description: "Map", submitOnChange:true, width:3
            if(logDebug) {
                input "buttonRebuild", "button", title: "Rebuild Table <small><abbr title='This should only be needed when changes to the table are made by the developer.'><b>- INFO -</b></abbr></small>", width: 3
            }
            if(refreshMap) {
                app.removeSetting("orderNumber")
                app.removeSetting("dimmerToSet")
                app.removeSetting("dimmerSetLevel")
                app.removeSetting("dimmerTemp")
                app.removeSetting("dimmerColor")
                app.removeSetting("cchue")
                app.removeSetting("ccsat")
                app.updateSetting("dimmerColorTemp",[value:"false",type:"bool"])               
                app.updateSetting("refreshMap",[value:"false",type:"bool"])
            }
            paragraph "<small>* Remember to click outside all fields before pressing a button. Also, sometimes the button needs to be pushed twiced to add/edit. Need to work on that!</small>"
            theLine = getFormat("line")
            paragraph "${theLine}"
            if(state.displayDimmerMap == null) {
                theMap = "No devices are setup"
            } else {
                theMap = state.displayDimmerMap
            }
            paragraph "${theMap}"
            // *** End Mode Map ***
            theLine = getFormat("line")
            paragraph "${theLine}"
            if(logEnable) paragraph "Debug: ${state.theDimmerMap}"
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Disable Apps Option")) {
            input "disableEE", "bool", title: "Disable an Event Engine Cog", defaultValue:false, submitOnChange:true, width:6
            if(disableEE) {
                //state.cogsList = null
                input "getCogs", "bool", title: "Update Cogs (if necessary)", defaultValue:false, submitOnChange:true, width:6
                if(getCogs) {
                    sendLocationEvent(name: "eeMapRequest", value: "nothing")
                    app.updateSetting("getCogs",[value:"false",type:"bool"])
                }
                pauseExecution(2000)
                if(state.cogsList) {
                    input "eeCog", "enum", title: "Select Cog to Pause", required:false, multiple:true, options: state.cogsList, submitOnChange:true
                    if(logDebug) paragraph "Debug: $eeCog"
                } else {
                    paragraph "Cogs List not available. Use option above to populate the Cogs list."
                }
                theLine = getFormat("line")
                paragraph "${theLine}"
            } else {
                app.removeSetting("eeCog")
            }
            
            input "disableRM", "bool", title: "Disable a Rule Machine Rule", defaultValue:false, submitOnChange:true
            if(disableRM) {
                input "rmRuleType", "bool", title: "Rule Type: Legacy Rules (off) or Rule 5.x and Over (on)", submitOnChange:true
                if(rmRuleType) {
                    def rules50 = RMUtils.getRuleList('5.0')
                    if(rules50) {
                        input "rmRule", "enum", title: "Select Rules 5.x to Pause", required:false, multiple:true, options: rules50, submitOnChange:true
                    } else {
                        paragraph "No active Rule 5.x found."
                    }
                } else {
                    def rules = RMUtils.getRuleList()
                    if(rules) {
                        input "rmRule", "enum", title: "Select Legacy Rules to Pause", required:false, multiple:true, options: rules, submitOnChange:true
                    } else {
                        paragraph "No active Legacy Rules found."
                    }
                }
                theLine = getFormat("line")
                paragraph "${theLine}"
            } else {
                app.removeSetting("rmRule")
                app.removeSetting("rmRuleType")
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Disable Devices Option")) {
            paragraph "<b>Only works with local devices</b> (Doesn't work with devices shared through Hub Mesh to this hub)"
            paragraph "Use this option to disable certain devices when the Scene is active."
            input "disableMDevices", "capability.motionSensor", title: "Motion Sensor(s) to Disable", submitOnChange:true, required:false, multiple:true
            input "disableSDevices", "capability.switches", title: "Switch(es) to Disable", submitOnChange:true, required:false, multiple:true
        }
                        
        section(getFormat("header-green", "${getImage("Blank")}"+" Other Options")) {
            paragraph "Sometimes devices can miss commands due to HE's speed. This option will allow you to adjust the time between commands being sent."
            input "actionDelay", "number", title: "Delay (in milliseconds - 1000 = 1 second, 3 sec max)", range: '1..3000', defaultValue:250, required:false, submitOnChange:true
            input "checkStates", "bool", title: "Use Check States <small><abbr title='If any device does not update correctly, this will try to fix it.'><b>- INFO -</b></abbr></small>", defaultValue:false, submitOnChange:true, width:6
            if(checkStates) {
                input "timesToCheck", "number", title: "Times to Check (1 to 3)", range: '1..3', submitOnChange:true, width:6
            } else {
                app.updateSetting("timesToCheck",[value:"false",type:"bool"])
            }
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            } else {
                app.removeSetting("logOffTime")
            }
        }
		display2()
	}
}

def installed() {
    if(logEnable) log.debug "Installed with settings (${state.version}): ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings (${state.version}): ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    subscribe(location, "eeChildMap", eeMapHandler)
    subscribe(dataDevice, "switch.on", startTheProcess)
    subscribe(dataDevice, "switch.off", endTheProcess)
}

def dimmerHandler(data) {
    if(logEnable) log.debug "In dimmerHandler (${state.version}) - data: ${data}"
    def (theType, newData) = data.split(";")
    if(state.theDimmerMap == null) state.theDimmerMap = [:]
    theDimmer = dimmerToSet.toString()
    if(theType == "add") {
        if(logEnable) log.debug "In dimmerHandler - ADD"
        if(dimmerSetLevel == null) dimmerSetLevel = "NA"
        if(dimmerTempType == null) theTempType = "false"
        if(dimmerTemp == null) dimmerTemp = "NA"        
        if(dimmerColor == null) dimmerColor = "NA"
        if(dimmerColor == "Custom Color") dimmerColor2 = "${cchue};${ccsat}"
        theValue = "${orderNumber}:${dimmerSetLevel}:${dimmerTempType}:${dimmerTemp}:${dimmerColor}:${dimmerColor2}"
        if(logEnable) log.debug "dimmer: ${dimmerToSet} - theValue: ${theValue}"
        state.theDimmerMap.put(dimmerToSet,theValue)
    } else if(theType == "del") {
        if(logEnable) log.debug "In dimmerHandler - DELETE"
        state.theDimmerMap.remove(theDimmer)
    } else if(theType == "clear") {
        if(logEnable) log.debug "In dimmerHandler - CLEAR"
        state.theDimmerMap = [:]  
    } else if(theType == "rebuild") {
        if(logEnable) log.debug "In dimmerHandler - REBUILD"
        if(state.theDimmerMap) state.theDimmerMap = state.theDimmerMap.sort { a, b -> a.value <=> b.value }
        state.theDimmerMap.each { dim ->
            dimKey = dim.key
            dimValue = dim.value
            def pieces = dimValue.split(":")
            try {
                theOrder = pieces[0]; theLevel = pieces[1]; theTempType = pieces[2]; theTemp = pieces[3]; theColor = pieces[4]; theColor2 = pieces[5]
            } catch (e) {
                
            }
            if(theLevel == null) theLevel = "NA"
            if(theTempType == null) theTempType = false
            if(theTemp == null) theTemp = "NA"
            if(theColor == null) theColor = "NA"
            if(theColor2 == null) theColor2 = "NA"
            theValue = "${theOrder}:${theLevel}:${theTempType}:${theTemp}:${theColor}:${theColor2}"
            if(logEnable) log.debug "Rebuilding: theDimmer: ${theDimmer} - theValue: ${theValue}"
            state.theDimmerMap.put(dimmerToSet,theValue)
        }
    }
    
// ***** Make Map *****    
    if(logEnable) log.debug "In dimmerHandler - Map: ${state.theDimmerMap}"
    if(state.theDimmerMap) {
        state.theDimmerMap = state.theDimmerMap.sort { a, b -> a.value <=> b.value }
        displayDimmerMap =  "<table width=90% align=center><tr><td><b><u>Order</u></b><td><b><u>Dimmer</u></b><td><b><u>Level</u></b><td><b><u>Temp</u></b><td><b><u>Color</u></b><td><b><u>CC</u></b>"
        state.theDimmerMap.each { dm ->
            dimKey = dm.key
            dimValue = dm.value
            def pieces = dimValue.split(":")
            try {
                theOrder = pieces[0]; theLevel = pieces[1]; theTempType = pieces[2]; theTemp = pieces[3]; theColor = pieces[4]; theColor2 = pieces[5]
            } catch (e) {
                log.warn "${app.label} - Something went wrong, please rebuild your table"
                if(logEnable) log.warn "In Make Map - Oops - theOrder(0): ${theOrder} - theLevel(1): ${theLevel} - theTempType[2]: ${theTempType} - theTemp(3): ${theTemp} - theColor(4): ${theColor} - theColor2(5): ${theColor2}"
            }
                
            if(theColor) theColor = theColor.replace("]","")
            displayDimmerMap += "<tr><td>${theOrder}<td>${dimKey}<td>${theLevel}<td>${theTemp}<td>${theColor}<td>${theColor2}"
        }                
        displayDimmerMap += "</table>"
    } else {
        displayDimmerMap = "Empty"
    }
    state.displayDimmerMap = displayDimmerMap
    app.removeSetting("orderNumber")
    app.removeSetting("dimmerToSet")
    app.removeSetting("dimmerSetLevel")
    app.removeSetting("dimmerTempType")
    app.removeSetting("dimmerTemp")
    app.removeSetting("dimmerColor")
    app.removeSetting("cchue")
    app.removeSetting("ccsat")
    app.updateSetting("dimmerColorTemp",[value:"false",type:"bool"])
}

def useCustomColorsHandler() {
    input "useCustomColors", "bool", title: "Use a Custom Color", submitOnChange:true
    if(useCustomColors) {
        input "cchue", "text", title: "Hue", width: 6, submitOnChange:true
        input "ccsat", "text", title: "Saturation", width: 6, submitOnChange:true
    } else {
        app.removeSetting("cchue")
        app.removeSetting("ccsat")
    }
    theColors = ['Soft White','White','Daylight','Warm White','Red','Green','Blue','Yellow','Orange','Purple','Pink']
    if(cchue && ccsat) theColors.add("Custom Color")
    return theColors
}

def startTheProcess(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "-------------------- start startTheProcess --------------------"
        if(logEnable) log.debug "In startTheProcess (${state.version})"
        if(disableEE) { eventEngineHandler("pauseCog") }
        if(disableRM) { ruleMachineHandler("pauseRule") }
        if(disableMDevices || disableSDevices) { disableDeviceHandler("disable") }
        if(state.theDimmerMap) {
            state.theDimmerMap = state.theDimmerMap.sort { a, b -> a.value <=> b.value }
            state.theDimmerMap.each { dm ->
                dimKey = dm.key
                dimValue = dm.value
                def pieces = dimValue.split(":")
                theOrder = pieces[0]; theLevel = pieces[1]; theTempType = pieces[2]; theTemp = pieces[3]; theColor = pieces[4]; theColor2 = pieces[5]
                theDevice == null
                masterDimmers.each { tmd ->
                    if(tmd.displayName.toString().trim() == dimKey.toString().trim()) {
                        theDevice = tmd
                    }
                }
                if(theDevice) {
                    if(theDevice.hasCommand('setColorTemperature') && onTemp) {
                        if(logEnable) log.debug "In startTheProcess - setColorTemp - $theDevice"
                        pauseExecution(actionDelay)
                        theDevice.setLevel(theLevel as Integer ?: 99)
                        pauseExecution(actionDelay)
                        onTemp = onTemp.toInteger()
                        theDevice.setColorTemperature(onTemp)
                    } else if(theDevice.hasCommand('setColor') && onColor != "No Change") {
                        if(logEnable) log.debug "In startTheProcess - setColor - $theDevice"
                        state.onColor = "${theColor}"
                        state.onColor2 = "${theColor2}"
                        state.onLevel = theLevel
                        setLevelandColorHandler()
                        pauseExecution(actionDelay)
                        theDevice.setColor(value)  
                    } else if(theDevice.hasCommand('setLevel')) {
                        if(logEnable && extraLogs) log.debug "In startTheProcess - setLevel - $theDevice"
                        pauseExecution(actionDelay)
                        theDevice.setLevel(theLevel as Integer ?: 99)
                    } else {
                        if(logEnable) log.debug "In startTheProcess - On - ${theDevice}"
                        pauseExecution(actionDelay)
                        theDevice.on()
                    }
                }
            }
            if(checkStates) { checkStateHandler("1") }
        }
        if(logEnable) log.debug "-------------------- End startTheProcess --------------------"
    }
}

def endTheProcess(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "-------------------- Start endTheProcess --------------------"
        if(logEnable) log.debug "In endTheProcess (${state.version})"
        if(disableEE) { eventEngineHandler("resumeCog") }
        if(disableRM) { ruleMachineHandler("resumeRule") }
        if(disableMDevices || disableSDevices) { disableDeviceHandler("enable") }
        
        // Just for testing
        masterDimmers.each { tmd ->
            tmd.off()
        }
        if(logEnable) log.debug "-------------------- End endTheProcess --------------------"
    }
}

def checkStateHandler(checkCount) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        state.allGood = true
        tCheck = timesToCheck.toInteger()
        cCount = checkCount.toInteger()
        if(cCount <= tCheck) {
            if(logEnable) log.debug "In checkStateHandler (${state.version}) - ***** Starting - cCount: ${cCount} is less than tCheck: ${tCheck} *****"
            if(state.theDimmerMap) {
                state.theDimmerMap = state.theDimmerMap.sort { a, b -> a.value <=> b.value }
                state.theDimmerMap.each { dm ->
                    dimKey = dm.key
                    dimValue = dm.value
                    def pieces = dimValue.split(":")
                    theOrder = pieces[0]; theLevel = pieces[1]; theTempType = pieces[2]; theTemp = pieces[3]; theColor = pieces[4]; theColor2 = pieces[5]
                    theDevice == null
                    masterDimmers.each { tmd ->
                        if(tmd.displayName.toString().trim() == dimKey.toString().trim()) {
                            theDevice = tmd
                        }
                    }
                    if(theDevice) {
                        if(theDevice.hasCommand('setColorTemperature') && onTemp) {
                            currentLevel = theDevice.currentValue("level")
                            currentColorTemp = theDevice.currentValue("colorTemperature")

                            if(currentLevel.toString() != theLevel.toString() || currentColorTemp.toString() != theTemp.toString()) {   
                                if(logEnable) log.debug "In checkStateHandler - setColorTemp - $theDevice - currentLevel: ${currentLevel} - currentColorTemp: ${currentColorTemp}"
                                pauseExecution(actionDelay)
                                theDevice.setLevel(theLevel as Integer ?: 99)
                                pauseExecution(actionDelay)
                                onTemp = onTemp.toInteger()
                                theDevice.setColorTemperature(onTemp)
                                state.allGood = false
                            }
                        } else if(theDevice.hasCommand('setColor') && onColor != "No Change") {
                            currentLevel = theDevice.currentValue("level")
                            currentColor = theDevice.currentValue("colorName")
                            currentHue = theDevice.currentValue("hue")
                            currentSat = theDevice.currentValue("saturation")

                            if(theColor.toString() == "Custom Color") {
                                (theHue, theSat) = theColor2.split(";")
                                if(currentHue.toString() != theHue.toString() || currentSat.toString() != theSat.toString() || currentLevel.toString() != theLevel.toString()) {
                                    if(logEnable) log.debug "In checkStateHandler - setColor - $theDevice - currentColor: ${currentColor} - currentLevel: ${currentLevel}"
                                    state.onColor2 = "${theColor2}"
                                    state.onLevel = theLevel
                                    setLevelandColorHandler()
                                    pauseExecution(actionDelay)
                                    theDevice.setColor(value)
                                    state.allGood = false
                                }
                            } else {
                                if(currentColor.toString() != theColor.toString() || currentLevel.toString() != theLevel.toString()) {
                                    if(logEnable) log.debug "In checkStateHandler - setColor - $theDevice - currentColor: ${currentColor} - currentLevel: ${currentLevel}"
                                    state.onColor = "${theColor}"
                                    state.onLevel = theLevel
                                    setLevelandColorHandler()
                                    pauseExecution(actionDelay)
                                    theDevice.setColor(value)
                                    state.allGood = false
                                }
                            }
                        } else if(theDevice.hasCommand('setLevel')) {
                            currentLevel = theDevice.currentValue("level")

                            if(currentLevel.toString() != theLevel.toString()) {
                                if(logEnable && extraLogs) log.debug "In checkStateHandler - setLevel - $theDevice - currentLevel: ${currentLevel}"
                                pauseExecution(actionDelay)
                                theDevice.setLevel(theLevel as Integer ?: 99)
                                state.allGood = false
                            }
                        } else {
                            currentSwitch = theDevice.currentValue("switch")

                            if(currentSwitch.toString() != "on") {
                                if(logEnable) log.debug "In checkStateHandler - On - ${theDevice} - currentSwitch: ${currentSwitch}"
                                pauseExecution(actionDelay)
                                theDevice.on()
                                state.allGood = false
                            }
                        }
                    }
                }
                if(logEnable) log.debug "In checkStateHandler - ***** Finished round ${checkCount} *****"
                if(state.allGood) {
                    if(logEnable) log.debug "In checkStateHandler - All Good! - Finished"
                } else {
                    cCount += 1
                    pauseExecution(actionDelay)
                    checkStateHandler(cCount)
                }
            }
        } else {
            if(logEnable) log.debug "In checkStateHandler - Check Maxed Out - Finished"
        }
    }
}

String getCookie(){
    try{
        httpPost(
            [
                uri: "http://127.0.0.1:8080",
                path: "/login",
                query: [ loginRedirect: "/" ],
                body: [
                    username: username,
                    password: password,
                    submit: "Login"
                ]
            ]
        ) { resp -> 
            cookie = ((List)((String)resp?.headers?.'Set-Cookie')?.split(';'))?.getAt(0) 
            if(debugEnable)
            log.debug "$cookie"
        }
    } catch (e){
        cookie = ""
    }
    return "$cookie"
}

def disableDeviceHandler(data) {
    if(logEnable) log.debug "In disableDeviceHandler (${state.version})"
    disableMDevices.each { disM ->
        deviceName = disM.displayName
        deviceID = disM.deviceId
        if(logEnable) log.debug "In disableDeviceHandler - Working on ${deviceName} (${deviceID}) - data: ${data}"
        if(data == "disable") {
            httpPost("http://127.0.0.1:8080/device/disable", "id=${deviceID}&disable=true", { it -> if(logEnable) log.debug "Disabled ${deviceName} (${deviceID})" })
        } else {
            httpPost("http://127.0.0.1:8080/device/disable", "id=${deviceID}&disable=false", { it -> if(logEnable) log.debug "Enabled ${deviceName} (${deviceID})" })
        }
    }
}

def setLevelandColorHandler() {  
    if(state.onColor == null || state.onColor == "null" || state.onColor == "") state.onColor = "No Change"
    if(state.onLevel == "NA") state.onLevel = null
    if(state.onTemp == "NA") state.onTemp = null
    if(logEnable) log.debug "In setLevelandColorHandler - color: ${state.onColor} - color2: ${state.onColor2} - temp: ${state.onTemp} - onLevel: ${state.onLevel}"
    switch(state.onColor) {
        case "No Change":
            hueColor = null
            saturation = null
            break;
        case "White":
            hueColor = 52
            saturation = 19
            break;
        case "Daylight":
            hueColor = 53
            saturation = 91
            break;
        case "Soft White":
            hueColor = 23
            saturation = 56
            break;
        case "Warm White":
            hueColor = 20
            saturation = 80
            break;
        case "Blue":
            hueColor = 70
            saturation = 100
            break;
        case "Green":
            hueColor = 39
            saturation = 100
            break;
        case "Yellow":
            hueColor = 25
            saturation = 100
            break;
        case "Orange":
            hueColor = 10
            saturation = 100
            break;
        case "Purple":
            hueColor = 75
            saturation = 100
            break;
        case "Pink":
            hueColor = 83
            saturation = 100
            break;
        case "Red":
            hueColor = 100
            saturation = 100
            break;
        case "Custom Color":
            (theHue,theSat) = state.onColor2.split(";")
            hueColor = theHue.toInteger()
            saturation = theSat.toInteger()
            break;
    }
    onLevel = state.onLevel
    if(logEnable) log.debug "In setLevelandColorHandler - 1 - hue: ${hueColor} - saturation: ${saturation} - onLevel: ${onLevel}"
    if(onLevel) onLevel = onLevel.toInteger()
    value = [hue: hueColor, saturation: saturation, level: onLevel]
    return value
}

def eeMapHandler(evt) {
    state.tCogs = evt.value.toString().replace(" <span style='color:red'>(Paused)</span>"," - Paused").replace("{","").replace("}","").split(", ")
    cogsList = []
    state.tCogs.each { it ->
        (theKey, theValue) = it.split("=")
        cogsList += theValue
    }
    state.cogsList = cogsList.sort { a, b -> a.toLowerCase() <=> b.toLowerCase() }
}

def ruleMachineHandler(doThis) {
    if(logEnable) log.debug "In ruleMachineHandler - rmRuleType: ${rmRuleType} - Rule: ${rmRule} - doThis: ${doThis}"
    if(rmRuleType) {
        RMUtils.sendAction(rmRule, doThis, app.label, '5.0')
    } else {
        RMUtils.sendAction(rmRule, doThis, app.label)
    }
}

def eventEngineHandler(doThis) {
    if(logEnable) log.debug "In eventEngineHandler - eeCog: ${eeCog} - doThis: ${doThis}"       
    eeCog.each { ee ->
        state.tCogs.each { it ->
            (theKey, theValue) = it.split("=")
            //log.trace "checking ee: ${ee} -VS- ${theValue}"
            if(theValue.toString() == ee.toString()) {                   
                eeNum = theKey
                if(logEnable) log.debug "In eventEngineHandler - eeCog: ${eeCog} - eeNum: ${eeNum}"
                sendLocationEvent(name: "eeCommand", value: "${eeNum}:${doThis}")
                pauseExecution(actionDelay)
            }
        }
    }
}

def appButtonHandler(buttonPressed) {
    state.whichButton = buttonPressed
    if(logEnable) log.debug "In appButtonHandler (${state.version}) - Button Pressed: ${state.whichButton}"
    if(dimmerToSet && state.whichButton == "buttonDel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${state.whichButton}"
        dimmerHandler("del;nothing")
        state.working = false
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(state.whichButton == "buttonRebuild") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${state.whichButton}"
        dimmerHandler("rebuild;nothing")
        state.working = false
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(dimmerToSet && state.whichButton == "buttonAdd") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${state.whichButton}"
        dimmerHandler("add;nothing")
        state.working = false
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(state.whichButton == "buttonCancel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${state.whichButton}"
        app.removeSetting("dimmerToSet")
        state.working = false
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(state.whichButton == "buttonClear"){
        if(logEnable) log.debug "In appButtonHandler - Working on: ${state.whichButton}"
        dimmerHandler("clear;nothing")
        state.working = false
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(state.whichButton == "resetMaps") {
        state.oldMap = [:]
        state.theDimmerMap = [:]
    }
}
