library (
        base: "app",
        author: "Bryan Turcotte",
        category: "Apps",
        description: "Standard Things for use with BPTWorld Apps",
        name: "bpt-blueIrisActions",
        namespace: "BPTWorld",
        documentationLink: "",
        version: "1.0.0",
        disclaimer: "This library is only for use with BPTWorld Apps and Drivers. If you wish to use any/all parts of this Library, please be sure to copy it to a new library and use a unique name. Thanks!"
)

def profileSwitchHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In switchChangeHandler (${state.version})"
        if(logEnable) log.debug "In switchChangeHandler - switchProfileOn: ${switchProfileOn}"
        if(switchProfileOn == "Pon0") {
            biChangeHandler("0")
        } else if(switchProfileOn == "Pon1") {
            biChangeHandler("1")
        } else if(switchProfileOn == "Pon2") {
            biChangeHandler("2")
        } else if(switchProfileOn == "Pon3") {
            biChangeHandler("3")
        } else if(switchProfileOn == "Pon4") {
            biChangeHandler("4")
        } else if(switchProfileOn == "Pon5") {
            biChangeHandler("5")
        } else if(switchProfileOn == "Pon6") {
            biChangeHandler("6")
        } else if(switchProfileOn == "Pon7") {
            biChangeHandler("7")
        }
    }
}

def scheduleSwitchHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In switchChangeHandler (${state.version})"
        if(logEnable) log.debug "In scheduleSwitchHandler - switchScheduleOn: ${biScheduleName}"
        biChangeHandler(biScheduleName)
    }
}

def cameraPresetHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In cameraPresetHandler (${state.version}) - biCameraPreset: ${biCameraPreset}"
        if(biCameraPreset == "PS1") {
            biChangeHandler("1")
        } else if(biCameraPreset == "PS2") {
            biChangeHandler("2")
        } else if(biCameraPreset == "PS3") {
            biChangeHandler("3")
        } else if(biCameraPreset == "PS4") {
            biChangeHandler("4")
        } else if(biCameraPreset == "PS5") {
            biChangeHandler("5")
        }
    }
}

def cameraSnapshotHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In cameraSnapshotHandler (${state.version})"
        if(logEnable) log.debug "In cameraSnapshotHandler - Switch on"
        biChangeHandler("0")
    }
}

def cameraTriggerHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In cameraTriggerHandler (${state.version})"
        if(logEnable) log.debug "cameraTriggerHandler - On"
        biChangeHandler("1")
    }
}

def cameraPTZHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In cameraPTZHandler (${state.version})"
        if(logEnable) log.debug "In cameraPTZHandler - biCameraPTZ: ${biCameraPTZ}"
        if(biCameraPTZ == "PTZ0") {
            biChangeHandler("0")
        } else if(biCameraPTZ == "PTZ1") {
            biChangeHandler("1")
        } else if(biCameraPTZ == "PTZ2") {
            biChangeHandler("2")
        } else if(biCameraPTZ == "PTZ3") {
            biChangeHandler("3")
        } else if(biCameraPTZ == "PTZ4") {
            biChangeHandler("4")
        } else if(biCameraPTZ == "PTZ5") {
            biChangeHandler("5")
        } else if(biCameraPTZ == "PTZ6") {
            biChangeHandler("6")
        }
    }
}

def cameraRebootHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In cameraRebootHandler (${state.version})"
        if(logEnable) log.debug "In cameraRebootHandler - Switch on"
        biChangeHandler("0")
    }
}

def biChangeHandler(num) {
    if(logEnable) log.debug "In biChangeHandler (${state.version}) - biControl: ${biControl}"
	biHost = "${parent.biServer}:${parent.biPort}"
	if(biControl == "Switch_Profile") {
		if(logEnable) log.debug "I'm in Switch_Profile"
		biRawCommand = "/admin?profile=${num}&user=${parent.biUser}&pw=${parent.biPass}"        
    } else if(biControl == "Switch_Contact_Motion") {
        if(logEnable) log.debug "I'm in Switch, Contact or Motion"
        biRawCommand = "/admin?profile=${num}&user=${parent.biUser}&pw=${parent.biPass}"       
    } else if(biControl == "Camera_Preset") {
        if(logEnable) log.debug "I'm in Camera_Preset"
        biRawCommand = "/admin?camera=${biCamera}&preset=${num}&user=${parent.biUser}&pw=${parent.biPass}"        
        // /admin?camera=x&preset=x
    } else if(biControl == "Camera_Snapshot") {
        if(logEnable) log.debug "I'm in Camera_Snapshot"
        biRawCommand = "/admin?camera=${biCamera}&snapshot&user=${parent.biUser}&pw=${parent.biPass}"        
        // /admin?camera=x&snapshot
    } else if(biControl == "Camera_Trigger") {
        if(logEnable) log.debug "I'm in Camera_Trigger"
        if(!useMethod) biRawCommand = "/admin?camera=${biCamera}&manrec=${num}&user=${parent.biUser}&pw=${parent.biPass}"
        if(useMethod) biRawCommand = "/admin?camera=${biCamera}&trigger&user=${parent.biUser}&pw=${parent.biPass}"        
        // NOTE: if this Command doesn't work for you, try the second one instead
        // /admin?camera=x&manrec=1
    } else if(biControl == "Camera_PTZ") {
        if(logEnable) log.debug "I'm in Camera_PTZ"
        biRawCommand = "/cam/${biCamera}/pos=${num}"        
        // /cam/{cam-short-name}/pos=x Performs a PTZ command on the specified camera, where x= 0=left, 1=right, 2=up, 3=down, 4=home, 5=zoom in, 6=zoom out
    } else if(biControl == "Camera_Reboot") {
        if(logEnable) log.debug "I'm in Camera_Reboot"
        biRawCommand = "/admin?camera=${biCamera}&reboot&user=${parent.biUser}&pw=${parent.biPass}"
        // /admin?camera=x&reboot
    } else if(biControl == "Camera_Enable" || biControl == "Camera_Disable") {
        if(logEnable) log.debug "I'm in Camera_Enable/Disable"
        biRawCommand = "/admin?camera=${biCamera}&enable=${num}&user=${parent.biUser}&pw=${parent.biPass}"           
        // /admin?camera=x&enable=1 or 0 Enable or disable camera x (short name)
    } else if(biControl == "Switch_Schedule") {    
        if(logEnable) log.debug "I'm in Switch_Schedule"
        biRawCommand = "/admin?schedule=${num}&user=${parent.biUser}&pw=${parent.biPass}"        
    } else {
        biRawCommand = "*** Something went wrong! ***"
    }
    if(logEnable) log.debug "In biChangeHandler - biHost: ${biHost} - biUser: ${parent.biUser} - biPass: ${parent.biPass} - num: ${num}"
	if(logEnable) log.debug "In biChangeHandler - sending GET to URL: ${biHost}${biRawCommand}"
	def httpMethod = "GET"
	def httpRequest = [
		method:		httpMethod,
		path: 		biRawCommand,
		headers:	[
			HOST:		biHost,
			Accept: 	"*/*",
		]
	]
	def hubAction = new hubitat.device.HubAction(httpRequest)
	sendHubCommand(hubAction)
}
