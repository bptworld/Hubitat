/**
 *  ****************  Event Engine Parent  ****************
 *
 *  Design Usage:
 *  Automate your world with easy to use Cogs. Rev up complex automations with just a few clicks!
 *
 *  Copyright 2020-2022 Bryan Turcotte (@bptworld)
 *
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 *
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  All Changes reflected in the Child App Header
 *  1.0.0 - 09/05/20 - Initial release.
 */

#include BPTWorld.bpt-normalStuff

definition(
    name:"Event Engine",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Automate your world with easy to use Cogs. Rev up complex automations with just a few clicks!",
    category: "Convenience",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: ""
)

def setVersion() {
    state.version = null
}

preferences {
    page name: "mainPage", title: "", install: true, uninstall: false
    page name: "removePage", title: "", install:false, uninstall:true
} 

def installed() {
    if(logEnable) log.debug "Installed with settings: ${settings}"
    initialize()
}

def updated() {
    if(logEnable) log.debug "Updated with settings: ${settings}"
    unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    initialize()
}

def initialize() {
    subscribe(location, "eeMapRequest", requestMapHandler)
    subscribe(location, "eeCommand", runEEHandler)
    
    mapOfChildren()
}

def mainPage() {
    dynamicPage(name: "mainPage") {
    	installCheck()
        if(state.appInstalled == 'COMPLETE'){
            display()
            section("Instructions:", hideable: true, hidden: true) {
                paragraph "<b>Information</b>"
                paragraph "Automate your world with easy to use Cogs. Rev up complex automations with just a few clicks!"
            }

            section() {
                paragraph "Remember: Options for Global Variables, Blue Iris and Calendarific can be found below the Cogs Section."
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" Cogs")) {
                app(name: "anyOpenApp", appName: "Event Engine Cog", namespace: "BPTWorld", title: "<b>Add a new 'Cog' to Event Engine</b>", multiple: true)
                //app(name: "anyOpenApp", appName: "Event Engine Cog TEST", namespace: "BPTWorld", title: "<b>Add a new 'TEST Cog' to Event Engine</b>", multiple: true)
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" Default Values")) {
                paragraph "Default Values are shared across all Cogs but can be changed within each Cog if needed."
                paragraph "<b>Special Action Option</b><br>Sometimes devices can miss commands due to HE's speed. This option will allow you to adjust the time between commands being sent."
                input "pActionDelay", "number", title: "Delay (in milliseconds - 1000 = 1 second, 3 sec max)", range: '1..3000', defaultValue:100, submitOnChange:true
                paragraph "<hr>"
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" Global Variables")) {
                paragraph "Global Variables can be accessed and updated by any EE Cog. A great way to share variables between Cogs!"
                paragraph "- <b>To add or edit a variable</b>, simply fill in the Name and Value below. Variable will be added as soon as you click outside the value field.<br>- <b>To delete a variable</b>, enter in the Name and flip the Add/Edit Delete switch to on."
                input "gName", "text", title: "Variable Name", required:false, width:6
                input "gValue", "text", title: "Set initial value", required:false, submitOnChange:true, width:6
                input "gvAED", "bool", title: "Add/Edit (off) or Delete (on)", description: "Add Edit Delete", defaultValue:false, submitOnChange:true, width:12
                if(gName && gvAED) {
                    gVariablesHandler("del;nothing")
                } else if(gName && gValue) {
                    gVariablesHandler("add;nothing")
                } else {
                    gVariablesHandler("refresh;nothing")
                }
                paragraph "<hr>"
                paragraph "${state.niceMap}"
                paragraph "<hr>"
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" Blue Iris Info")) {
                paragraph "If you are planning on using EE to control Blue Iris, enter in your Server Config information here."
                input "useBI", "bool", title: "Use Blue Iris?", description: "Blue Iris", defaultValue:false, submitOnChange:true
                if(useBI) {
                    paragraph "In Blue Iris settings > Web Server > Advanced Settings<br> - Ensure 'Use secure session keys and login page' is not checked.<br> - Disable authentication, select “Non-LAN only” (preferred) or “No” to disable authentication altogether.<br> - Blue Iris only allows Admin Users to toggle profiles."
                    paragraph "<b>Use the local IP address for Host, do not include http:// or anything but the IP address. ie. 192.168.1.123</b>"
                    input "biServer", "text", title: "Server", description: "Blue Iris web server IP", required: false
                    input "biPort", "number", title: "Port", description: "Blue Iris web server port", required: false
                    input "biUser", "text", title: "User name", description: "Blue Iris user name", required: false
                    input "biPass", "password", title: "Password", description: "Blue Iris password", required: false
                } else {
                    app.removeSetting("biServer")
                    app.removeSetting("biPort")
                    app.removeSetting("biUser")
                    app.removeSetting("biPass")
                }
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" Calendarific Info")) {
                paragraph "If you are planning on using Calendarific to control EE, enter in your Server Config information here."
                input "useCal", "bool", title: "Use Calendarific?", description: "Blue Iris", defaultValue:false, submitOnChange:true
                if(useCal) {
                    paragraph "Get your FREE key from <a href='https://calendarific.com/' target=_blank'>Calendarific</a>."
                    input "apiKey", "text", title: "API Key", required:true, submitOnChange:true
                } else {
                    app.removeSetting("apiKey")
                }
            }

            section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
                label title: "Enter a name for parent app (optional)", required: false
                input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
                if(logEnable) {
                    input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours"]
                }
            }
            display2()
        }    
    }
}

def gVariablesHandler(data) {
    if(logEnable) log.debug "In gVariablesHandler (${state.version}) - data: ${data}"
    def (theType, newData) = data.split(";")
    if(state.gvMap == null) state.gvMap = [:]    
    if(theType == "fromChild") {
        def (cName, cValue) = newData.split(":")
        state.gvMap.put(cName,cValue)
    } else if(theType == "add") {
        state.gvMap.put(gName,gValue)
    } else if(theType == "del") {
        state.gvMap.remove(gName)
    }
      
    if(state.gvMap) {
        niceMap =  "<table width=50% align=center><tr><td><b><u>Name</u></b><td>   <td><b><u>Value</u></b>"
        def theData = "${state.gvMap}".split(",")
        theData.each { it -> 
            def (name, value) = it.split(":")
            if(name.startsWith(" ") || name.startsWith("[")) name = name.substring(1)
            value = value.replace("]","")
            niceMap += "<tr><td>${name}<td> - <td>${value}"
        }                
        niceMap += "</table>"
    }
    state.niceMap = niceMap
    
    app.removeSetting("gName")
    app.removeSetting("gValue")
    app?.updateSetting("gvAED",[value:"false",type:"bool"])
    sendToChildren()
}

def sendToChildren() {
    if(state.gvMap) childApps.each { child ->
        child.globalVariablesHandler(state.gvMap)
    }
}

def selectCogtoParent(data) {
    if(logEnable) log.debug "In selectCogtoParent (${state.version}) - data: ${data}"
    childApps.each { it ->
        if(it.label == data) {
            log.info "Match - ${data}"
            state.mySettings = it.mySettings
        }  
    }
    app.updateSetting("mySettings",[value:"${state.mySettings}",type:"text"])
}

def requestMapHandler(evt) {
    cMap = [:]
    childApps.each { cog ->
        cMap.put("${cog.id}", "${cog.label}")
        //cMap += "[\"${cog.id}\":\"${cog.label}\"]"
    }
    sendLocationEvent(name: "eeChildMap", value: cMap)
}

def mapOfChildren(data) {
    theID = data.toString()
    cMap = [:]
    childApps.each { cog ->
        cMap.put("${cog.id}", "${cog.label}")
    }     
    if(cMap) {
        childApps.each { cog ->
            cogID = cog.id.toString()
            if(cogID == theID) {
                if(logEnable) log.debug "In runEEHandler - Sending Map of Children to: ${cog.label} ($cog.id)"
                cog.mapOfChildrenHandler(cMap)
            }
        }
    }
}

def runEEHandler(evt) {
    data = evt.value
    if(logEnable) log.debug "In runEEHandler (${state.version}) - data: ${data}"
    (theID, cogCommand) = data.split(":")
    theID = theID.toString()
    childApps.each { cog ->
        cogID = cog.id.toString()
        if(cogID == theID) {
            if(logEnable) log.debug "In runEEHandler - Setting Cog: ${cog.label} ($cog.id) to ${cogCommand}"
            cog.commandFromParentHandler(cogCommand)
        }
    }
}

def installCheck(){
	state.appInstalled = app.getInstallationState() 
	if(state.appInstalled != 'COMPLETE'){
		section("<b>Welcome!</b>") {
            paragraph "Please hit 'Done' to install the '${app.label}' parent app."
        }
  	}
  	else{
    	if(logEnable) log.info "Parent Installed - Good to go"
  	}
}
