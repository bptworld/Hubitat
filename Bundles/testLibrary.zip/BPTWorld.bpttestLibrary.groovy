library (
        author: "Bryan Turcotte",
        category: "Apps",
        description: "Test Library for BPTWorld Apps",
        name: "bpt-testLibrary",
        namespace: "BPTWorld",
        documentationLink: "",
        version: "1.0.0",
        disclaimer: "This library is only for use with BPTWorld Apps and Drivers. If you wish to use any/all parts of this Library, please be sure to copy it to a new library and use a unique name. Thanks!"
)