/**
 *  **************** Simple Multi Tile Child App  ****************
 *
 *  Design Usage:
 *  Create a simple multi device tile with just a few clicks
 *
 *  Copyright 2021-2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  1.0.6 - 08/15/22 - Bundle Manager changes
 *  1.0.5 - 05/06/22 - Bundle Manager
 *  1.0.4 - 01/28/22 - Fixed typos, thanks to @boris.juraga. Nice catch!
 *  1.0.3 - 06/05/21 - Added a 6th line
 *  1.0.2 - 06/05/21 - Added a few functions
 *  1.0.1 - 06/05/21 - Fixed an error
 *  1.0.0 - 06/04/21 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Simple Multi Tile"
	state.version = "1.0.6"
}

def syncVersion(evt){
    setVersion()
    sendLocationEvent(name: "updateVersionsInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Simple Multi Tile Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Create a simple multi device tile with just a few clicks",
    category: "Convenience",
	parent: "BPTWorld:Simple Multi Tile",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Create a simple multi device tile with just a few clicks"
            paragraph "Remember, this is a SIMPLE multi tile app.  If you need more, please take a look at Tile Master."
		}

        section(getFormat("header-green", "${getImage("Blank")}"+" Virtual Device")) {
            paragraph "Each child app needs a virtual device to store the transformed results."
            input "useExistingDevice", "bool", title: "Use existing device (off) or have DT create a new one for you (on)", defaultValue:false, submitOnChange:true
            if(useExistingDevice) {
                input "dataName", "text", title: "Enter a name for this vitual Device (ie. 'SMT - Front Door')", required:true, submitOnChange:true
                paragraph "<b>A device will automatically be created for you as soon as you click outside of this field.</b>"
                if(dataName) createDataChildDevice()
                if(statusMessageD == null) statusMessageD = "Waiting on status message..."
                paragraph "${statusMessageD}"
            }
            input "dataDevice", "capability.actuator", title: "Virtual Device specified above", required:true, multiple:false
            if(!useExistingDevice) {
                app.removeSetting("dataName")
                paragraph "<small>* Device must use the 'Simple Multi Tile Driver'.</small>"
            }
        } 
       
        section(getFormat("header-green", "${getImage("Blank")}"+" Device to Track")) {
            input "howManyAtt", "enum", title: "How many Attributes per Device", options: [
                ["1":"one"],
                ["2":"two"],
                ["3":"three"]
            ], submitOnChange:true
            if(howManyAtt) hMA = howManyAtt.toInteger()
            input "device1", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device1) {
                allAttrs1 = []
                allAttrs1 = device1.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs1a = allAttrs1.sort { a, b -> a.value <=> b.value }
                input "deviceAtt1a", "enum", title: "Attribute to track", options: allAttrs1a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt1b", "enum", title: "Attribute to track", options: allAttrs1a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt1c", "enum", title: "Attribute to track", options: allAttrs1a, required:false, multiple:false, submitOnChange:true, width:4
            }
            
            input "device2", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device2) {
                allAttrs2 = []
                allAttrs2 = device2.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs2a = allAttrs2.sort { a, b -> a.value <=> b.value }
                input "deviceAtt2a", "enum", title: "Attribute to track", options: allAttrs2a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt2b", "enum", title: "Attribute to track", options: allAttrs2a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt2c", "enum", title: "Attribute to track", options: allAttrs2a, required:false, multiple:false, submitOnChange:true, width:4
            }
            
            input "device3", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device3) {
                allAttrs3 = []
                allAttrs3 = device3.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs3a = allAttrs3.sort { a, b -> a.value <=> b.value }
                input "deviceAtt3a", "enum", title: "Attribute to track", options: allAttrs3a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt3b", "enum", title: "Attribute to track", options: allAttrs3a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt3c", "enum", title: "Attribute to track", options: allAttrs3a, required:false, multiple:false, submitOnChange:true, width:4
            }
            
            input "device4", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device4) {
                allAttrs4 = []
                allAttrs4 = device4.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs4a = allAttrs4.sort { a, b -> a.value <=> b.value }
                input "deviceAtt4a", "enum", title: "Attribute to track", options: allAttrs4a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt4b", "enum", title: "Attribute to track", options: allAttrs4a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt4c", "enum", title: "Attribute to track", options: allAttrs4a, required:false, multiple:false, submitOnChange:true, width:4
            }
            
            input "device5", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device5) {
                allAttrs5 = []
                allAttrs5 = device5.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs5a = allAttrs5.sort { a, b -> a.value <=> b.value }
                input "deviceAtt5a", "enum", title: "Attribute to track", options: allAttrs5a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt5b", "enum", title: "Attribute to track", options: allAttrs5a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt5c", "enum", title: "Attribute to track", options: allAttrs5a, required:false, multiple:false, submitOnChange:true, width:4
            }
            
            input "device6", "capability.*", title: "Select a device", required:false, multiple:false, submitOnChange:true
            if(device6) {
                allAttrs6 = []
                allAttrs6 = device6.supportedAttributes.flatten().unique{ it.name }.collectEntries{ [(it):"${it.name.capitalize()}"] }
                allAttrs6a = allAttrs6.sort { a, b -> a.value <=> b.value }
                input "deviceAtt6a", "enum", title: "Attribute to track", options: allAttrs6a, required:true, multiple:false, submitOnChange:true, width:4
                if(hMA > 1) input "deviceAtt6b", "enum", title: "Attribute to track", options: allAttrs6a, required:false, multiple:false, submitOnChange:true, width:4
                if(hMA > 2) input "deviceAtt6c", "enum", title: "Attribute to track", options: allAttrs6a, required:false, multiple:false, submitOnChange:true, width:4
            }
        }
               
        section(getFormat("header-green", "${getImage("Blank")}"+" Filter Options")) {
            paragraph "To save characters, enter in a filter to remove characters from each device name. Must be exact, including case.<br><small>ie. 'Motion Sensor', 'Bedroom', 'Contact'</small>"
			input "bFilter1", "text", title: "Filter 1", required:false, submitOnChange:true, width:6
            input "bFilter2", "text", title: "Filter 2", required:false, submitOnChange:true, width:6            
            input "bFilter3", "text", title: "Filter 3", required:false, submitOnChange:true, width:6
            input "bFilter4", "text", title: "Filter 4", required:false, submitOnChange:true, width:6
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Other Options")) {
            input "showHeader", "bool", title: "Show Table Header?", defaultValue:false, submitOnChange:true
            if(showHeader) {
                input "headerName1", "text", title: "Column 1 Name", submitOnChange:true, width:3
                input "headerName2", "text", title: "Column 2 Name", submitOnChange:true, width:3
                if(hMA > 1) input "headerName3", "text", title: "Column 3 Name", submitOnChange:true, width:3
                if(hMA > 2) input "headerName4", "text", title: "Column 4 Name", submitOnChange:true, width:3
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" The Tile")) {
            theDeviceHandler()
            paragraph "${state.theTable}", width:10
            paragraph "<hr>"
            paragraph "Table Count: ${state.tableCount}<br>* Must be under 1024 to show on a Tile."
        }
		display2()
	}
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    subscribe(location, "getVersionsInfo", syncVersion)
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(device1) {
            if(deviceAtt1a) subscribe(device1, deviceAtt1a, theDeviceHandler)
            if(deviceAtt1b) subscribe(device1, deviceAtt1b, theDeviceHandler)
            if(deviceAtt1c) subscribe(device1, deviceAtt1c, theDeviceHandler)
        }
        if(device2) {
            if(deviceAtt2a) subscribe(device2, deviceAtt2a, theDeviceHandler)
            if(deviceAtt2b) subscribe(device2, deviceAtt2b, theDeviceHandler)
            if(deviceAtt2c) subscribe(device2, deviceAtt2c, theDeviceHandler)
        }
        if(device3) {
            if(deviceAtt3a) subscribe(device3, deviceAtt3a, theDeviceHandler)
            if(deviceAtt3b) subscribe(device3, deviceAtt3b, theDeviceHandler)
            if(deviceAtt3c) subscribe(device3, deviceAtt3c, theDeviceHandler)
        }
        if(device4) {
            if(deviceAtt4a) subscribe(device4, deviceAtt4a, theDeviceHandler)
            if(deviceAtt4b) subscribe(device4, deviceAtt4b, theDeviceHandler)
            if(deviceAtt4c) subscribe(device4, deviceAtt4c, theDeviceHandler)
        }
        if(device5) {
            if(deviceAtt5a) subscribe(device5, deviceAtt5a, theDeviceHandler)
            if(deviceAtt5b) subscribe(device5, deviceAtt5b, theDeviceHandler)
            if(deviceAtt5c) subscribe(device5, deviceAtt5c, theDeviceHandler)
        }
        if(device6) {
            if(deviceAtt6a) subscribe(device6, deviceAtt6a, theDeviceHandler)
            if(deviceAtt6b) subscribe(device6, deviceAtt6b, theDeviceHandler)
            if(deviceAtt6c) subscribe(device6, deviceAtt6c, theDeviceHandler)
        }
    }
}

def theDeviceHandler(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In theDeviceHandler (${state.version})"
        if(evt) whatHappened = evt.value
        state.recognised = false
        if(logEnable) log.debug "In theDeviceHandler - whatHappened: ${whatHappened}"
        if(howManyAtt) hMA = howManyAtt.toInteger()
        if(device1) { 
            currentDevice1a = device1.currentValue(deviceAtt1a) ?: ""
            currentDevice1b = device1.currentValue(deviceAtt1b) ?: ""
            currentDevice1c = device1.currentValue(deviceAtt1c) ?: ""
        }
        if(device2) { 
            currentDevice2a = device2.currentValue(deviceAtt2a) ?: ""
            currentDevice2b = device2.currentValue(deviceAtt2b) ?: ""
            currentDevice2c = device2.currentValue(deviceAtt2c) ?: ""
        }
        if(device3) { 
            currentDevice3a = device3.currentValue(deviceAtt3a) ?: ""
            currentDevice3b = device3.currentValue(deviceAtt3b) ?: ""
            currentDevice3c = device3.currentValue(deviceAtt3c) ?: ""
        }
        if(device4) {
            currentDevice4a = device4.currentValue(deviceAtt4a) ?: ""
            currentDevice4b = device4.currentValue(deviceAtt4b) ?: ""
            currentDevice4c = device4.currentValue(deviceAtt4c) ?: ""
        }
        if(device5) { 
            currentDevice5a = device5.currentValue(deviceAtt5a) ?: ""
            currentDevice5b = device5.currentValue(deviceAtt5b) ?: ""
            currentDevice5c = device5.currentValue(deviceAtt5c) ?: ""
        }
        if(device6) { 
            currentDevice6a = device6.currentValue(deviceAtt6a) ?: ""
            currentDevice6b = device6.currentValue(deviceAtt6b) ?: ""
            currentDevice6c = device6.currentValue(deviceAtt6c) ?: ""
        }
        
        if(device1) {
            theName1 = device1.displayName          
            if(bFilter1) { theName1 = theName1.replace("${bFilter1}", "") }
            if(bFilter2) { theName1 = theName1.replace("${bFilter2}", "") }
            if(bFilter3) { theName1 = theName1.replace("${bFilter3}", "") }
            if(bFilter4) { theName1 = theName1.replace("${bFilter4}", "") }
        }
        if(device2) {
            theName2 = device2.displayName              
            if(bFilter1) { theName2 = theName2.replace("${bFilter1}", "") }
            if(bFilter2) { theName2 = theName2.replace("${bFilter2}", "") }
            if(bFilter3) { theName2 = theName2.replace("${bFilter3}", "") }
            if(bFilter4) { theName2 = theName2.replace("${bFilter4}", "") }
        }
        if(device3) {
            theName3 = device3.displayName              
            if(bFilter1) { theName3 = theName3.replace("${bFilter1}", "") }
            if(bFilter2) { theName3 = theName3.replace("${bFilter2}", "") }
            if(bFilter3) { theName3 = theName3.replace("${bFilter3}", "") }
            if(bFilter4) { theName3 = theName3.replace("${bFilter4}", "") }
        }
        if(device4) {
            theName4 = device4.displayName              
            if(bFilter1) { theName4 = theName4.replace("${bFilter1}", "") }
            if(bFilter2) { theName4 = theName4.replace("${bFilter2}", "") }
            if(bFilter3) { theName4 = theName4.replace("${bFilter3}", "") }
            if(bFilter4) { theName4 = theName4.replace("${bFilter4}", "") }
        }
        if(device5) {
            theName5 = device5.displayName              
            if(bFilter1) { theName5 = theName5.replace("${bFilter1}", "") }
            if(bFilter2) { theName5 = theName5.replace("${bFilter2}", "") }
            if(bFilter3) { theName5 = theName5.replace("${bFilter3}", "") }
            if(bFilter4) { theName5 = theName5.replace("${bFilter4}", "") }
        }
        if(device6) {
            theName6 = device6.displayName              
            if(bFilter1) { theName6 = theName6.replace("${bFilter1}", "") }
            if(bFilter2) { theName6 = theName6.replace("${bFilter2}", "") }
            if(bFilter3) { theName6 = theName6.replace("${bFilter3}", "") }
            if(bFilter4) { theName6 = theName6.replace("${bFilter4}", "") }
        }

        if(showHeader) {
            if(hMA == 1) state.theTable = "<table width=100%><tr><td width=55% align=left><u><b>${headerName1}</u></b><td width=15% align=left><u><b>${headerName2}</u></b>"
            if(hMA > 1)  state.theTable = "<table width=100%><tr><td width=55% align=left><u><b>${headerName1}</u></b><td width=15% align=left><u><b>${headerName2}</u></b><td width=15% align=left><u><b>${headerName3}</u></b>"
            if(hMA > 2)  state.theTable = "<table width=100%><tr><td width=55% align=left><u><b>${headerName1}</u></b><td width=15% align=left><u><b>${headerName2}</u></b><td width=15% align=left><u><b>${headerName3}</u></b><td width=15% align=left><u><b>${headerName4}</u></b>"
        } else {
            state.theTable = "<table width=100%><tr><td colSpan=4>"
        }
        if(device1) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName1}<td width=15% align=left>${currentDevice1a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName1}<td width=15% align=left>${currentDevice1a}<td width=15% align=left>${currentDevice1b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName1}<td width=15% align=left>${currentDevice1a}<td width=15% align=left>${currentDevice1b}<td width=15% align=left>${currentDevice1c}"
        }
        if(device2) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName2}<td width=15% align=left>${currentDevice2a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName2}<td width=15% align=left>${currentDevice2a}<td width=15% align=left>${currentDevice2b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName2}<td width=15% align=left>${currentDevice2a}<td width=15% align=left>${currentDevice2b}<td width=15% align=left>${currentDevice2c}"
        }
        if(device3) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName3}<td width=15% align=left>${currentDevice3a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName3}<td width=15% align=left>${currentDevice3a}<td width=15% align=left>${currentDevice3b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName3}<td width=15% align=left>${currentDevice3a}<td width=15% align=left>${currentDevice3b}<td width=15% align=left>${currentDevice3c}"
        }
        if(device4) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName4}<td width=15% align=left>${currentDevice4a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName4}<td width=15% align=left>${currentDevice4a}<td width=15% align=left>${currentDevice4b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName4}<td width=15% align=left>${currentDevice4a}<td width=15% align=left>${currentDevice4b}<td width=15% align=left>${currentDevice4c}"
        }
        if(device5) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName5}<td width=15% align=left>${currentDevice5a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName5}<td width=15% align=left>${currentDevice5a}<td width=15% align=left>${currentDevice5b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName5}<td width=15% align=left>${currentDevice5a}<td width=15% align=left>${currentDevice5b}<td width=15% align=left>${currentDevice5c}"
        }
        if(device6) {
            if(hMA == 1) state.theTable += "<tr><td width=55% align=left>${theName6}<td width=15% align=left>${currentDevice6a}"
            if(hMA == 2) state.theTable += "<tr><td width=55% align=left>${theName6}<td width=15% align=left>${currentDevice6a}<td width=15% align=left>${currentDevice6b}"
            if(hMA == 3) state.theTable += "<tr><td width=55% align=left>${theName6}<td width=15% align=left>${currentDevice6a}<td width=15% align=left>${currentDevice6b}<td width=15% align=left>${currentDevice6c}"
        }
        state.theTable += "</table>"
        
        if(state.theTable) { state.tableCount = state.theTable.size() }
        if(logEnable) log.debug "In theDeviceHandler - tableCount: ${state.tableCount}"
        if(dataDevice) {
            dataDevice.sendEvent(name: "bpt-simpleMultiTile", value: state.theTable, isStateChange: true)
            dataDevice.sendEvent(name: "tableCount", value: state.tableCount, isStateChange: true)  
            dataDevice.sendEvent(name: "lastUpdated", value: new Date(), isStateChange: true)  
        }
    }
}

def createDataChildDevice() {    
    if(logEnable) log.debug "In createDataChildDevice (${state.version})"
    statusMessageD = ""
    if(!getChildDevice(dataName)) {
        if(logEnable) log.debug "In createDataChildDevice - Child device not found - Creating device: ${dataName}"
        try {
            addChildDevice("BPTWorld", "Simple Multi Tile Driver", dataName, 1234, ["name": "${dataName}", isComponent: false])
            if(logEnable) log.debug "In createDataChildDevice - Child device has been created! (${dataName})"
            statusMessageD = "<b>Device has been been created. (${dataName})</b>"
        } catch (e) { if(logEnable) log.debug "Simple Multi Tile was unable to create device - ${e}" }
    } else {
        statusMessageD = "<b>Device Name (${dataName}) already exists.</b>"
    }
    return statusMessageD
}
