/**
 *  **************** Quick Chart Child App  ****************
 *
 *  Design Usage:
 *  Chart your data, quickly and easily. Display your charts in any dashboard.
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  0.0.4 - 07/14/22 - Rewrite, rewrite, rewrite...
 *  0.0.3 - 07/13/22 - Minor changes
 *  0.0.2 - 07/12/22 - Added option for background color
 *  0.0.1 - 07/12/22 - Initial release.
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Quick Chart"
	state.version = "0.0.4"
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Quick Chart Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Chart your data, quickly and easily. Display your charts in any dashboard.",
    category: "Convenience",
	parent: "BPTWorld:Quick Chart",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Chart your data, quickly and easily. Display your charts in any dashboard."
		}
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Virtual Device")) {
            createDeviceSection("Quick Chart Driver")
        }
        
        if(dataDevice) {
            section(getFormat("header-green", "${getImage("Blank")}"+" Device Options")) {
                paragraph "Each Device created can hold up to 10 Charts. Select the slot to store THIS Chart."
                input "theSlot", "enum", title: "Chart Number", options: ["chart01","chart02","chart03","chart04","chart05","chart06","chart07","chart08","chart09","chart10"], required:true, submitOnChange:true
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Graph Options")) {
            input "gType", "enum", title: "Chart Style", options: ["bar","line","radar","pie","doughnut","polar","scatter","bubble","radialGauge","violin","sparkline","progressBar",""], submitOnChange:true, width:6
            input "theChartTitle", "text", title: "Chart Title", submitOnChange:true, width:6
            
            input "bkgrdColor", "text", title: "Background Color", defaultValue:"white", submitOnChange:true            
            input "showDevInAtt", "bool", title: "Show Device Name with Attribute in Chart Header", defaultValue:false, submitOnChange:true
            input "theDevice", "capability.*", title: "Select the Device(s)", multiple:true, submitOnChange:true
            if(theDevice) {
                allAttrs = []
                theDevice.each { dev ->
                    attributes = dev.supportedAttributes
                    attributes.each { att ->
                        theType = att.getDataType()
                        if(theType == "NUMBER") {
                            allAttrs << att.name
                        }
                    }
                }
                devAtt = allAttrs.unique().sort()
                input "theAtt", "enum", title: "Select the Attribute(s)<br><small>Only Choose Numeric Attributes</small>", options: devAtt, multiple:true, submitOnChange:true
            }

            if(theAtt) {
                input "theDays", "enum", title: "Select Days to Graph<br><small>* Remember to check how many data points are saved, per attribute, for device selected.</small>", multiple:false, required:true, options: [
                    ["99":"Today"],
                    ["1":"+ 1 Day"],
                    ["2":"+ 2 Days"],
                    ["3":"+ 3 Days"],
                    ["4":"+ 4 Days"],
                    ["5":"+ 5 Days"],
                    ["6":"+ 6 Days"],
                    ["7":"+ 7 Days"]
                ], defaultValue:"99", submitOnChange:true
                input "decimals", "enum", title: "Number of Decimal places", options: ["None","1","2"], defaultValue:"None", submitOnChange:true                
                input "updateTime", "enum", title: "When to Update", options: [
                    ["manual":"Manual"],
                    ["realTime":"Real Time"],
                    ["5min":"Every 5 Minutes"],
                    ["10min":"Every 10 Minutes"],
                    ["15min":"Every 15 Minutes"],
                    ["30min":"Every 30 Minutes"],
                    ["1hour":"Every 1 Hour"],
                    ["3hour":"Every 3 Hours"]
                ], defaultValue:"manual", submitOnChange:true 
            }
        }
    
        section() {
            input "makeGraph", "bool", title: "Make Graph", defaultValue:false, submitOnChange:true
            if(makeGraph) {
                getEventsHandler()
                app.updateSetting("makeGraph",[value:"false",type:"bool"])
            }
            if(buildChart) {
                paragraph "${buildChart}"
            } else {
                paragraph ""
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:true
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }
		display2()
	}
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(updateTime == "realTime") {
            if(theDevice && theAtt) {
                theDevice.each { td ->
                    theAtt.each { ta ->
                        subscribe(td, ta, getEventsHandler)
                    }
                }
            }
        } else if(updateTime == "5min") {
            runEvery5Minutes(getEventsHandler)
        } else if(updateTime == "10min") {
            runEvery10Minutes(getEventsHandler) 
        } else if(updateTime == "15min") {
            runEvery15Minutes(getEventsHandler)
        } else if(updateTime == "30min") {
            runEvery30Minutes(getEventsHandler)
        } else if(updateTime == "1hour") {
            runEvery1Hour(getEventsHandler)
        } else if(updateTime == "3hour") {
            runEvery3Hours(getEventsHandler)
        }
    }
}

def getEventsHandler(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In getEventsHandler (${state.version})"
        events = []
        def today = new Date().clearTime()
        if(theDays) {
            if(theDays == "99") {
                days = today
            } else {
                days = today - theDays.toInteger()
            }

            if(logEnable) log.debug "In getEventsHandler - theDevice: ${theDevice} - ${theAtt} - ${days} (${theDays})"
            if(theDevice && theAtt) {
                eventMap = [:]
                theDevice.each { theD ->
                    theAtt.each { att ->
                        if(theD.hasAttribute(att)) {
                            events = theD.statesSince(att, days, [max: 2000]).collect{[ date:it.date, value:it.value]}.flatten().reverse()
                            theKey = "${theD};${att.capitalize()}"
                            eventMap.put(theKey,events)
                        }
                    }
                }
            }
            graphingHandler(eventMap)
        }
    }
}

def graphingHandler(eventMap) {
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In graphingHandler (${state.version})"
        x=1
        theLabels = []
        theData = []
        if(eventMap) {
            eventMap.each { it ->
                (theDev,theAtt) = it.key.split(";")
                if(showDevInAtt) {
                    theAtt = "${theDev} - ${theAtt}"
                } else {
                    theAtt = "${theAtt}"
                }
                
                theD = it.value
                theD.each { tdata ->
                    //log.trace "tdata: $tdata"
                    //log.trace "starting $x - $tdata.date -- $tdata.value"
                    tDate = tdata.date.format("EEE hh:mm").toString()
                    if(decimals == "None") {
                        tValue = new BigDecimal(tdata.value).setScale(0, java.math.RoundingMode.HALF_UP)
                    } else if(decimals == "1") {
                        tValue = new BigDecimal(tdata.value).setScale(1, java.math.RoundingMode.HALF_UP)
                    } else {
                        tValue = new BigDecimal(tdata.value).setScale(2, java.math.RoundingMode.HALF_UP)
                    }
                    theLabels << "'${tDate}'"
                    theData << tValue
                    //log.info "Ending - $x"
                }
                if(x==1) {
                    buildChart = "<img width='100%' src=\"https://quickchart.io/chart?bkg=$bkgrdColor&c={type:'${gType}',data:{labels:${theLabels},datasets:[{label:'${theAtt}',data:${theData}}"
                } else {
                    buildChart += ",{label:'${theAtt}',data:${theData}}"
                }

                x += 1
                theLabels = []
                theData = []
            }
            buildChart += "]},options: {title: {display: true,text: '${theChartTitle}'}}}\">"
            // Send Graph to Device
            if(dataDevice && theGraph && theSlot) {
                dataDevice.sendEvent(name: theSlot, value: buildChart, isStateChange: true)   
            }
        }
    }
}

/*

theGraph = "<img width=\"100%\" src=\"https://quickchart.io/chart?bkg="+ bkgrdColor +"&c={type:'${gType}',data:{labels:"+ theLabels1 +",datasets:[{label:'"+ theAtt1 +"',data:"+ theData1 +"},{label:'"+ theAtt2 +"',data:"+ theData2 +"}]},options: {title: {display: true,text: '"+ theChartTitle +"'}}}\">"

*/
