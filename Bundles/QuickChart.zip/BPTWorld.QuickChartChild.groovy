/**
 *  **************** Quick Chart Child App  ****************
 *
 *  Design Usage:
 *  Chart your data, quickly and easily. Display your charts in any dashboard.
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  0.0.2 - 07/12/22 - Added option for background color
 *  0.0.1 - 07/12/22 - Initial release.
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Quick Chart"
	state.version = "0.0.2"
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Quick Chart Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Chart your data, quickly and easily. Display your charts in any dashboard.",
    category: "Convenience",
	parent: "BPTWorld:Quick Chart",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Chart your data, quickly and easily. Display your charts in any dashboard."
		}
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Virtual Device")) {
            createDeviceSection("Quick Chart Driver")
        }
        
        if(dataDevice) {
            section(getFormat("header-green", "${getImage("Blank")}"+" Device Options")) {
                paragraph "Each Device created can hold up to 10 Charts. Select the slot to store THIS Chart."
                input "theSlot", "enum", title: "Chart Number", options: ["chart01","chart02","chart03","chart04","chart05","chart06","chart07","chart08","chart09","chart10"], required:true, submitOnChange:true
                
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Graph Options")) {
            input "gType", "enum", title: "Type of Graph", options: ["bar","line","radar","pie","doughnut","polar","scatter","bubble","radialGauge","violin","sparkline","progressBar",""], submitOnChange:true
            input "bkgrdColor", "text", title: "Background Color", defaultValue:"white", submitOnChange:true
            input "theChartTitle", "text", title: "Chart Title", submitOnChange:true
            input "multiDevAtt", "bool", title: "Use Multiple Devices (off) or Multiple Attributes (on)", defaultValue:false, submitOnChange:true
            if(multiDevAtt) {
                input "theDevice", "capability.*", title: "Select a Device", submitOnChange:true
                if(theDevice) {
                    devAtt = theDevice.getSupportedAttributes().collect { it.getName() }.unique().sort()
                    input "theAtt", "enum", title: "Select an Attribute (choose up to 4)<br><small>Only Choose Numeric Attributes</small>", options: devAtt, multiple:true, submitOnChange:true
                }
            } else {
                input "theDevice", "capability.*", title: "Select a Device (choose up to 4)", multiple:true, submitOnChange:true
                if(theDevice) {
                    allAttrs = []
                    theDevice.each { dev ->
                        attributes = dev.supportedAttributes
                        attributes.each { att ->
                            theType = att.getDataType()
                            if(theType == "NUMBER") {
                                allAttrs << att.name
                            }
                        }
                    }
                    devAtt = allAttrs.unique().sort()
                    input "theAtt", "enum", title: "Select an Attribute<br><small>Only Choose Numeric Attributes</small>", options: devAtt, submitOnChange:true
                }
            }
            if(theAtt) {
                input "theDays", "enum", title: "Select Days to Graph<br><small>* Remember to check how many data points are saved, per attribute, for device selected.</small>", multiple:false, required:true, options: [
                    ["99":"Today"],
                    ["1":"+ 1 Day"],
                    ["2":"+ 2 Days"],
                    ["3":"+ 3 Days"],
                    ["4":"+ 4 Days"],
                    ["5":"+ 5 Days"],
                    ["6":"+ 6 Days"],
                    ["7":"+ 7 Days"]
                ], defaultValue:"99", submitOnChange:true
                input "decimals", "enum", title: "Number of Decimal places", options: ["None","1","2"], defaultValue:"None", submitOnChange:true                
                input "updateTime", "enum", title: "When to Update", options: [
                    ["manual":"Manual"],
                    ["realTime":"Real Time"],
                    ["5min":"Every 5 Minutes"],
                    ["10min":"Every 10 Minutes"],
                    ["15min":"Every 15 Minutes"],
                    ["30min":"Every 30 Minutes"],
                    ["1hour":"Every 1 Hour"],
                    ["3hour":"Every 3 Hours"]
                ], defaultValue:"manual", submitOnChange:true 
                
                // %deviceName%: %attributeName%
            }
        }
    
        section() {
            input "makeGraph", "bool", title: "Make Graph", defaultValue:false, submitOnChange:true
            if(makeGraph) {
                getEventsHandler()
                app.updateSetting("makeGraph",[value:"false",type:"bool"])
            }
            if(theGraph) {
                paragraph "${theGraph}"
            } else {
                paragraph ""
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:true
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }
		display2()
	}
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(updateTime == "realTime") {
            if(multiDevAtt) {
                if(theAtt) {
                    theAtt.each { ta ->
                        subscribe(theDevice, ta, getEventsHandler)
                    }
                }
            } else {
                if(theDevice) {
                    theDevice.each { td ->
                        subscribe(td, theAtt, getEventsHandler)
                    }
                }
            }
        } else if(updateTime == "5min") {
            runEvery5Minutes(getEventsHandler)
        } else if(updateTime == "10min") {
            runEvery10Minutes(getEventsHandler) 
        } else if(updateTime == "15min") {
            runEvery15Minutes(getEventsHandler)
        } else if(updateTime == "30min") {
            runEvery30Minutes(getEventsHandler)
        } else if(updateTime == "1hour") {
            runEvery1Hour(getEventsHandler)
        } else if(updateTime == "3hour") {
            runEvery3Hours(getEventsHandler)
        }
    }
}

def getEventsHandler(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In getEventsHandler (${state.version})"
        events = []

        def today = new Date().clearTime()
        if(theDays == "99") {
            days = today
        } else {
            days = today - theDays.toInteger()
        }

        if(logEnable) log.debug "In getEventsHandler - theDevice: ${theDevice} - ${theAtt} - ${days} (${theDays})"
        if(multiDevAtt) {
            if(theAtt) {
                x=1
                theAtt.each { att ->
                    events = theDevice.statesSince(att, days, [max: 2000]).collect{[ date:it.date, value:it.value]}.flatten().reverse()
                    if(x==1) {
                        att1 = att.toString().capitalize()
                        events1 = events
                    }
                    if(x==2) {
                        att2 = att.toString().capitalize()
                        events2 = events
                    }
                    if(x==3) {
                        att3 = att.toString().capitalize()
                        events3 = events
                    }
                    if(x==4) {
                        att4 = att.toString().capitalize()
                        events4 = events
                    }
                    x += 1
                }
            }
        } else {
            if(theDevice) {
                x=1
                theDevice.each { theD ->
                    if(x <= 4) {
                        events = theD.statesSince(theAtt, days, [max: 2000]).collect{[ date:it.date, value:it.value]}.flatten().reverse()
                        if(x==1) {
                            att1 = theD
                            events1 = events
                        }
                        if(x==2) {
                            att2 = theD
                            events2 = events
                        }
                        if(x==3) {
                            att3 = theD
                            events3 = events
                        }
                        if(x==4) {
                            att4 = theD
                            events4 = events
                        }
                    }
                    x += 1
                }
            }
        }
        graphingHandler(att1,events1,att2,events2,att3,events3,att4,events4)
    }
}

def graphingHandler(att1=null,events1=null,att2=null,events2=null,att3=null,events3=null,att4=null,events4=null) {
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In graphingHandler (${state.version})"
        theLabels1 = []
        theData1 = []
        theLabels2 = []
        theData2 = []
        theLabels3 = []
        theData3 = []
        theLabels4 = []
        theData4 = []
        if(events1) {
            theAtt1 = att1
            events1.each { it ->
                tDate = it.date.format("EEE hh:mm").toString()
                if(decimals == "None") {
                    tValue = new BigDecimal(it.value).setScale(0, java.math.RoundingMode.HALF_UP)
                } else if(decimals == "1") {
                    tValue = new BigDecimal(it.value).setScale(1, java.math.RoundingMode.HALF_UP)
                } else {
                    tValue = new BigDecimal(it.value).setScale(2, java.math.RoundingMode.HALF_UP)
                }
                theLabels1 << "'${tDate}'"
                theData1 << tValue
            }
        }
        if(events2) {
            theAtt2 = att2
            events2.each { it ->
                tDate = it.date.format("EEE hh:mm").toString()
                if(decimals == "None") {
                    tValue = new BigDecimal(it.value).setScale(0, java.math.RoundingMode.HALF_UP)
                } else if(decimals == "1") {
                    tValue = new BigDecimal(it.value).setScale(1, java.math.RoundingMode.HALF_UP)
                } else {
                    tValue = new BigDecimal(it.value).setScale(2, java.math.RoundingMode.HALF_UP)
                }
                theLabels2 << "'${tDate}'"
                theData2 << tValue
            }
        }
        if(events3) {
            theAtt3 = att3
            events3.each { it ->
                tDate = it.date.format("EEE hh:mm").toString()
                if(decimals == "None") {
                    tValue = new BigDecimal(it.value).setScale(0, java.math.RoundingMode.HALF_UP)
                } else if(decimals == "1") {
                    tValue = new BigDecimal(it.value).setScale(1, java.math.RoundingMode.HALF_UP)
                } else {
                    tValue = new BigDecimal(it.value).setScale(2, java.math.RoundingMode.HALF_UP)
                }
                theLabels3 << "'${tDate}'"
                theData3 << tValue
            }
        }
        if(events4) {
            theAtt4 = att4
            events4.each { it ->
                tDate = it.date.format("EEE hh:mm").toString()
                if(decimals == "None") {
                    tValue = new BigDecimal(it.value).setScale(0, java.math.RoundingMode.HALF_UP)
                } else if(decimals == "1") {
                    tValue = new BigDecimal(it.value).setScale(1, java.math.RoundingMode.HALF_UP)
                } else {
                    tValue = new BigDecimal(it.value).setScale(2, java.math.RoundingMode.HALF_UP)
                }
                theLabels4 << "'${tDate}'"
                theData4 << tValue
            }
        }
        if(logEnable) log.trace "--------------------------- Start ${theAtt1} ---------------------------"
        if(logEnable) log.trace "theLabels1: ${theLabels1}"
        if(logEnable) log.trace "-----------------------------------------------------------------"
        if(logEnable) log.trace "theData1: ${theData1}"
        if(logEnable) log.trace "--------------------------- End --------------------------------------"        
        if(events2) {
            if(logEnable) log.trace "--------------------------- ${theAtt2} ---------------------------"
            if(logEnable) log.trace "theLabels2: ${theLabels2}"
            if(logEnable) log.trace "-----------------------------------------------------------------"
            if(logEnable) log.trace "theData2: ${theData2}"
            if(logEnable) log.trace "--------------------------- End --------------------------------------"
        }   
        if(events3) {
            if(logEnable) log.trace "--------------------------- ${theAtt3} ---------------------------"
            if(logEnable) log.trace "theLabels3: ${theLabels3}"
            if(logEnable) log.trace "-----------------------------------------------------------------"
            if(logEnable) log.trace "theData3: ${theData3}"
            if(logEnable) log.trace "--------------------------- End --------------------------------------"
        }       
        if(events4) {
            if(logEnable) log.trace "--------------------------- ${theAtt4} ---------------------------"
            if(logEnable) log.trace "theLabels4: ${theLabels4}"
            if(logEnable) log.trace "-----------------------------------------------------------------"
            if(logEnable) log.trace "theData4: ${theData4}"
            if(logEnable) log.trace "--------------------------- End --------------------------------------"
        }
        
        if(events4) {
            theGraph = "<img width=\"100%\" src=\"https://quickchart.io/chart?bkg="+ bkgrdColor +"&c={type:'${gType}',data:{labels:"+ theLabels1 +",datasets:[{label:'"+ theAtt1 +"',data:"+ theData1 +"},{label:'"+ theAtt2 +"',data:"+ theData2 +"},{label:'"+ theAtt3 +"',data:"+ theData3 +"},{label:'"+ theAtt4 +"',data:"+ theData4 +"}]},options: {title: {display: true,text: '"+ theChartTitle +"'}}}\">"
            
        } else if(events3) {
            theGraph = "<img width=\"100%\" src=\"https://quickchart.io/chart?bkg="+ bkgrdColor +"&c={type:'${gType}',data:{labels:"+ theLabels1 +",datasets:[{label:'"+ theAtt1 +"',data:"+ theData1 +"},{label:'"+ theAtt2 +"',data:"+ theData2 +"},{label:'"+ theAtt3 +"',data:"+ theData3 +"}]},options: {title: {display: true,text: '"+ theChartTitle +"'}}}\">"
            
        } else if(events2) {
            theGraph = "<img width=\"100%\" src=\"https://quickchart.io/chart?bkg="+ bkgrdColor +"&c={type:'${gType}',data:{labels:"+ theLabels1 +",datasets:[{label:'"+ theAtt1 +"',data:"+ theData1 +"},{label:'"+ theAtt2 +"',data:"+ theData2 +"}]},options: {title: {display: true,text: '"+ theChartTitle +"'}}}\">"
            
        } else {
            theGraph = "<img width=\"100%\" src=\"https://quickchart.io/chart?bkg="+ bkgrdColor +"&c={type:'${gType}',data:{labels:"+ theLabels1 +",datasets:[{label:'"+ theAtt1 +"',data:"+ theData1 +"}]},options: {title: {display: true,text: '"+ theChartTitle +"'}}}\">"
            
        }
        // Send Graph to Device
        if(theGraph) {
            dataDevice.sendEvent(name: theSlot, value: theGraph, isStateChange: true)   
        }        
    }
}
