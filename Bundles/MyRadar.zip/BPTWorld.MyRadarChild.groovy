/**
 *  **************** MyRadar Child App  ****************
 *
 *  Design Usage:
 *  Get the current conditions and weather forecast for the next week from MyRadar
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  0.0.2 - 08/15/22 - Bundle Manager changes
 *  0.0.1 - 07/03/22 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "MyRadar"
	state.version = "0.0.2"
}

def syncVersion(evt){
    setVersion()
    sendLocationEvent(name: "updateVersionsInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "MyRadar Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Get the current conditions and weather forecast for the next week from MyRadar",
    category: "Convenience",
	parent: "BPTWorld:MyRadar",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Get the current conditions and weather forecast for the next week from MyRadar"
		}
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Virtual Device")) {
            createDeviceSection("MyRadar Driver")
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Requirements")) {
            input "lat", "text", title: "Latitude", submitOnChange:true, width:6
            input "lon", "text", title: "Longitude", submitOnChange:true, width:6
            input "mrKey", "password", title: "MyRadar Key<br>Get one <a href='https://myradar.dev/' target=_blank>here</a>", submitOnChange:true, width:6
            input "rUnits", "enum", title: "Units", options: ["us","si","ca","uk2"], defaultValue: "us", submitOnChange:true, width:6
            
            paragraph "When selecting the Update frequency, be sure to stay under the 1000 free calls a month. Will add some checks and warnings at a later time. Also will add a time frame to check the weather, ie 7am to 10pm. That way we can check more frequently without going over the quota."
            
            input "autoUpdate", "enum", title: "Gets updates every", submitOnChange:true, options: ["1 Minute","5 Minutes","10 Minute","15 Minute","30 Minute","1 Hour","3 Hours"], required:true
            
            input "getWeather", "bool", title: "Get weather conditions now", submitOnChange:true
            if(getWeather) {
                getWeatherHandler()
                app.updateSetting("getWeather",[value:"false",type:"bool"])
            }
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }

		display2()
	}
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        subscribe(location, "getVersionsInfo", syncVersion)
        if(autoUpdate == "1 Minute") runEvery1Minute(getWeatherHandler)
        if(autoUpdate == "5 Minutes") runEvery5Minutes(getWeatherHandler)
        if(autoUpdate == "10 Minutes") runEvery10Minutes(getWeatherHandler)
        if(autoUpdate == "15 Minutes") runEvery15Minutes(getWeatherHandler)
        if(autoUpdate == "30 Minutes") runEvery30Minutes(getWeatherHandler)
        if(autoUpdate == "1 Hour") runEvery1Hour(getWeatherHandler)
        if(autoUpdate == "3 Hours") runEvery3Hours(getWeatherHandler)
    }
}

def getWeatherHandler() {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In getWeatherHandler (${state.version})"

        forecastURL = "https://api.myradar.dev/forecast/${lat},${lon}?units=${rUnits}"
    
        if(logEnable) log.debug "In getWeatherHandler - forecastURL: ${forecastURL}"
        def requestParams =
            [
                uri: forecastURL,
                requestContentType: "application/json",
                contentType: "application/json",
                timeout: 30,
                headers: [
                    "Cache-Control": "no-cache",
                    "Subscription-Key": "${mrKey}"
                ]
                
            ]
        try {
            httpGet(requestParams) { response ->
                if(logEnable) log.info "In getWeatherHandler - response: ${response.status}"
                if(response.status == 200) {
                    state.allCurrently = []
                    def rec = response.data.currently

                    time                 = rec.time
                    summary              = rec.summary
                    icon                 = rec.icon
                    precipIntensity      = rec.precipIntensity
                    precipProbability    = rec.precipProbability
                    precipType           = rec.precipType
                    temperature          = rec.temperature
                    apparentTemperature  = rec.apparentTemperature
                    dewPoint             = rec.dewPoint
                    humidity             = rec.humidity
                    pressure             = rec.pressure
                    windSpeed            = rec.windSpeed
                    windGust             = rec.windGust
                    windBearing          = rec.windBearing
                    cloudCover           = rec.cloudCover
                    uvIndex              = rec.uvIndex
                    visibility           = rec.visibility
                    ozone                = rec.ozone
                    
                    state.allCurrently = []
                    def daily = response.data.daily

                    dailySummary                 = daily.summary
                    sevenDaySummary              = daily.data.summary
                    
                    try {
                        state.alerts = []
                        def al = response.data.alerts
                        aTitle               = response.data.alerts.title
                        aDescription         = response.data.alerts.description
                        aSeverity            = response.data.alerts.severity
                        aTime                = response.data.alerts.time
                        aExpires             = response.data.alerts.expires
                    } catch(e) { }
                    
                    units                = response.data.flags.units

                    Date date = new Date(time * 1000L)
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a")
                    String lastReceived = dateFormat.format(date)

                    if(lastReceived == null) lastReceived = "NA"
                    if(epochTime == null) epochTime = "NA"
                    if(summary == null) summary = "NA"
                    if(precipIntensity == null) precipIntensity = "NA"
                    if(precipProbability == null) precipProbability = "NA"
                    if(precipType == null) precipType = "NA"
                    if(temperature == null) temperature = "NA"
                    if(apparentTemperature == null) apparentTemperature = "NA"
                    if(dewPoint == null) dewPoint = "NA"
                    if(humidity == null) humidity = "NA"
                    if(pressure == null) pressure = "NA"
                    if(windSpeed == null) windSpeed = "NA"
                    if(windGust == null) windGust = "NA"
                    if(windBearing == null) windBearing = "NA"
                    if(cloudCover == null) cloudCover = "NA"
                    if(uvIndex == null) uvIndex = "NA"
                    if(visibility == null) visibility = "NA"
                    if(ozone == null) ozone = "NA"
                    
                    dataDevice.sendEvent(name: "lastReceived", value: lastReceived, isStateChange: true)
                    dataDevice.sendEvent(name: "epochTime", value: time, isStateChange: true)
                    dataDevice.sendEvent(name: "summary", value: summary, isStateChange: true)
                    dataDevice.sendEvent(name: "precipIntensity", value: precipIntensity, isStateChange: true)
                    dataDevice.sendEvent(name: "precipProbability", value: precipProbability, isStateChange: true)
                    dataDevice.sendEvent(name: "precipType", value: precipType, isStateChange: true)
                    dataDevice.sendEvent(name: "temperature", value: temperature, isStateChange: true)
                    dataDevice.sendEvent(name: "apparentTemperature", value: apparentTemperature, isStateChange: true)
                    dataDevice.sendEvent(name: "dewPoint", value: dewPoint, isStateChange: true)
                    dataDevice.sendEvent(name: "humidity", value: humidity, isStateChange: true)
                    dataDevice.sendEvent(name: "pressure", value: pressure, isStateChange: true)
                    dataDevice.sendEvent(name: "windSpeed", value: windSpeed, isStateChange: true)
                    dataDevice.sendEvent(name: "windGust", value: windGust, isStateChange: true)
                    dataDevice.sendEvent(name: "windBearing", value: windBearing, isStateChange: true)
                    dataDevice.sendEvent(name: "cloudCover", value: cloudCover, isStateChange: true)
                    dataDevice.sendEvent(name: "uvIndex", value: uvIndex, isStateChange: true)
                    dataDevice.sendEvent(name: "visibility", value: visibility, isStateChange: true)
                    dataDevice.sendEvent(name: "ozone", value: ozone, isStateChange: true)
                    
                    def theDate = new Date()
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(theDate);
                    def day = calendar.get(Calendar.DAY_OF_WEEK);

                    def map=[
                        1:"Sunday",
                        2:"Monday",
                        3:"Tuesday",
                        4:"Wednesday",
                        5:"Thursday",
                        6:"Friday",
                        7:"Saturday"
                    ]

                    theRec = 1; dailySum = sevenDaySummary.toString().replace("[","").replace("]","").split(",")
                    dailySum.each { it ->
                        if(theRec < 7) {
                            d = day+theRec
                            tDay = map[d]
                            dataDevice.sendEvent(name: "day${theRec}Summary", value: "${tDay}:${it}", isStateChange: true)
                            theRec += 1
                        }
                    }

                    if(alertTitle == null) { 
                        dataDevice.sendEvent(name: "alertTitle", value: "No alerts found", isStateChange: true)
                        dataDevice.off()
                    } else {
                        dataDevice.sendEvent(name: "alertTitle", value: aTitle, isStateChange: true)
                        dataDevice.on()
                    }
                    
                    try{
                        Date adate = new Date(aTime * 1000L)
                        String aIssued = dateFormat.format(adate)

                        Date xdate = new Date(aExpires * 1000L)
                        String aExpires = dateFormat.format(xdate)
                    } catch(e) {
                        // nothing
                    }

                    if(aIssued == null) aIssued = "NA"
                    if(aExpires == null) aExpires = "NA"
                    if(aDescription == null) aDescription = "NA"
                    if(aSeverity == null) aSeverity = "NA"
                    if(aTime == null) aTime = "NA"
                    if(aExpires == null) aExpires = "NA"
                    
                    dataDevice.sendEvent(name: "alertIssued", value: aIssued, isStateChange: true)
                    dataDevice.sendEvent(name: "alertExpires", value: aExpires, isStateChange: true)
                    dataDevice.sendEvent(name: "alertDescription", value: aDescription, isStateChange: true)
                    dataDevice.sendEvent(name: "alertSeverity", value: aSeverity, isStateChange: true)
                    dataDevice.sendEvent(name: "alertTime", value: aTime, isStateChange: true)
                    dataDevice.sendEvent(name: "alertExpires", value: aExpires, isStateChange: true)

                    dataDevice.sendEvent(name: "units", value: units, isStateChange: true)

                    combinedCurrently = "${time}::${summary}::${icon}::${precipIntensity}::${precipProbability}::${precipType}::${temperature}::${apparentTemperature}::${dewPoint}::${humidity}::${pressure}::${windSpeed}::${windGust}::${windBearing}::${cloudCover}::${uvIndex}::${visibility}::${ozone}"
                    state.allCurrently << combinedCurrently
                }
            }
        } catch(e) {
            log.error(getExceptionMessageWithLine(e))
        }
    }
}
