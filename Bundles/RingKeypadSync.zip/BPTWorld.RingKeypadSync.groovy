/**
 *  **************** Ring Keypad Sync App  ****************
 *
 *  Design Usage:
 *  Keep multiple Ring Alarm Keypads in Sync
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  1.0.1 - 08/05/22 - Added other syncing options
 *  1.0.0 - 08/05/22 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Keypad Sync"
	state.version = "1.0.1"
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Ring Keypad Sync",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Keep multiple Ring Alarm Keypads in Sync",
    category: "Convenience",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "",
)

preferences {
    page(name: "pageConfig")
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Keep multiple Ring Alarm Keypads in Sync"
		}
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Keypad Status Sync")) {
            paragraph "When using the keypads with 'other' security applications, this option makes it easy to keep multiple keypads in sync."
            input "theKeypads", "capability.securityKeypad", title: "Select the Keypads to sync the 'securityKeypad' attribute and Status Lights<br><small>* Do NOT use with Hubitat Safety Monitor</small>", multiple:true, submitOnChange:true
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Attribute Sync")) {
            paragraph "Update attributes on the master keypad and let this app automatically update the secondary keypads! Must be used on the hub that has the keypads installed (not on meshed hub)"
            input "mKeypad", "capability.securityKeypad", title: "Select the Master Keypad to 'watch' for changes", multiple:false, submitOnChange:true, width:6
            input "sKeypads", "capability.securityKeypad", title: "Select the Secondary Keypads to update", multiple:true, submitOnChange:true, width:6
            paragraph "<hr>"
            paragraph "Choose the attributes you would like to update (Master to Secondary)"
            input "armAwayDelay", "bool", title: "Update armAwayDelay", defaultValue:false, submitOnChange:true, width:6
            input "armHomeDelay", "bool", title: "Update armHomeDelay", defaultValue:false, submitOnChange:true, width:6
            input "codeLength", "bool", title: "Update codeLength", defaultValue:false, submitOnChange:true, width:6
            input "lockCodes", "bool", title: "Update lockCodes", defaultValue:false, submitOnChange:true, width:6
            input "volAnnouncement", "bool", title: "Update volAnnouncement", defaultValue:false, submitOnChange:true, width:6
            input "volKeytone", "bool", title: "Update volKeytone", defaultValue:false, submitOnChange:true, width:6
            input "volSiren", "bool", title: "Update volSiren", defaultValue:false, submitOnChange:true, width:6
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }

		display2()
	}
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(theKeypads) subscribe(theKeypads, "securityKeypad", keypadHandler)
        if(mKeypad && sKeypads) {
            if(armAwayDelay) subscribe(mKeypad, "armAwayDelay", attributeHandler)
            if(armHomeDelay) subscribe(mKeypad, "armHomeDelay", attributeHandler)
            if(codeLength) subscribe(mKeypad, "codeLength", attributeHandler)
            if(lockCodes) subscribe(mKeypad, "lockCodes", attributeHandler)
            if(volAnnouncement) subscribe(mKeypad, "volAnnouncement", attributeHandler)
            if(volKeytone) subscribe(mKeypad, "volKeytone", attributeHandler)
            if(volSiren) subscribe(mKeypad, "volSiren", attributeHandler)
        }
    }
}

def keypadHandler(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In keypadHandler (${state.version}) - evt: $evt.data"
        evtName = evt.displayName        
        if(logEnable) log.debug "In keypadHandler - evtName: ${evtName}"
        theKeypads.each { tk ->
            if(tk.toString() == evtName.toString()) {
                theValue = tk.currentValue("securityKeypad")
            }
        }
        theKeypads.each { tk ->
            if(tk.toString() == evtName.toString()) {
                // Do nothing
            } else {
                dValue = tk.currentValue("securityKeypad")
                if(logEnable) log.debug "In keypadHandler - dValue: ${dValue} -VS- theValue: ${theValue}"
                if(dValue != theValue) {
                    tk.sendEvent(name: "securityKeypad", value: theValue, isStateChange: false)
                    if(theValue == "disarmed") {
                        tk.keypadUpdateStatus(0x02, "digital", "")
                    } else if(theValue == "armed home") {
                        tk.keypadUpdateStatus(0x0A, "digital", "")
                    } else if(theValue == "armed away") {
                        tk.keypadUpdateStatus(0x0B, "digital", "")
                    }
                }
            }
        }
    }
}

def attributeHandler(evt) {
    checkEnableHandler()
    if(pauseApp || state.eSwitch) {
        log.info "${app.label} is Paused or Disabled"
    } else {
        if(logEnable) log.debug "In attributeHandler (${state.version})"

        if(armAwayDelay) aDelay = mKeypad.currentValue("armAwayDelay")
        if(armHomeDelay) hDelay = mKeypad.currentValue("armHomeDelay")
        if(codeLength) cLength = mKeypad.currentValue("codeLength")
        if(lockCodes) lCodes = mKeypad.currentValue("lockCodes")
        if(volAnnouncement) volA = mKeypad.currentValue("volAnnouncement")
        if(volKeytone) volK = mKeypad.currentValue("volKeytone")
        if(volSiren) volS = mKeypad.currentValue("volSiren")
        
        sKeypads.each { sk ->
            if(logEnable) log.debug "In attributeHandler - Updating ${sk.displayName}"
            if(armAwayDelay) sk.sendEvent(name: "armAwayDelay", value: aDelay, isStateChange: true)
            if(armHomeDelay) sk.sendEvent(name: "armHomeDelay", value: hDelay, isStateChange: true)
            if(codeLength) sk.sendEvent(name: "codeLength", value: cLength, isStateChange: true)                
            if(lockCodes) sk.sendEvent(name: "lockCodes", value: lCodes, isStateChange: true)               
            if(volAnnouncement) sk.sendEvent(name: "volAnnouncement", value: volA, isStateChange: true)
            if(volKeytone) sk.sendEvent(name: "volKeytone", value: volK, isStateChange: true)
            if(volSiren) sk.sendEvent(name: "volSiren", value: volS, isStateChange: true)
        }
    }
}
