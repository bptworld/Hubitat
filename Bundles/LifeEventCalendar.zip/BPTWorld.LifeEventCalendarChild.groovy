/**
 *  **************** Life Event Calendar App  ****************
 *
 *  Design Usage:
 *  Never miss an important Life Event again! Schedule reminders easily and locally.
 *
 *  Copyright 2022 Bryan Turcotte (@bptworld)
 * 
 *  This App is free.  If you like and use this app, please be sure to mention it on the Hubitat forums!  Thanks.
 *
 *  Remember...I am not a professional programmer, everything I do takes a lot of time and research!
 *  Donations are never necessary but always appreciated.  Donations to support development efforts are accepted via: 
 *
 *  Paypal at: https://paypal.me/bptworld
 * 
 *  Unless noted in the code, ALL code contained within this app is mine. You are free to change, ripout, copy, modify or
 *  otherwise use the code in anyway you want. This is a hobby, I'm more than happy to share what I have learned and help
 *  the community grow. Have FUN with it!
 * 
 *-------------------------------------------------------------------------------------------------------------------
 *  Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 *  in compliance with the License. You may obtain a copy of the License at:
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed
 *  on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License
 *  for the specific language governing permissions and limitations under the License.
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  If modifying this project, please keep the above header intact and add your comments/credits below - Thank you! -  @BPTWorld
 *
 *  App and Driver updates can be found at https://github.com/bptworld/Hubitat/
 *
 * ------------------------------------------------------------------------------------------------------------------------------
 *
 *  Changes:
 *
 *  1.0.6 - 05/06/22 - Bundle Manager
 *  1.0.5 - 04/28/22 - Bug hunt
 *  1.0.4 - 04/27/22 - Major rewrite
 *  1.0.3 - 03/31/22 - Added optional 'delay' between commands. Now displays the Next Event and the Next 3 Events in the Data Device.
 *  1.0.2 - 03/27/22 - Added 'repeat yearly'
 *  1.0.1 - 03/27/22 - Fixed schedules overwriting each other. Added 'repeat in x days'.
 *  1.0.0 - 03/27/22 - Initial release.
 *
 */

#include BPTWorld.bpt-normalStuff

def setVersion(){
    state.name = "Life Event Calendar"
	state.version = "1.0.5"
    sendLocationEvent(name: "updateVersionInfo", value: "${state.name}:${state.version}")
}

definition(
    name: "Life Event Calendar Child",
    namespace: "BPTWorld",
    author: "Bryan Turcotte",
    description: "Never miss an important Life Event again! Schedule reminders easily and locally.",
    category: "Convenience",
	parent: "BPTWorld:Life Event Calendar",
    iconUrl: "",
    iconX2Url: "",
    iconX3Url: "",
	importUrl: "https://raw.githubusercontent.com/bptworld/Hubitat/master/Apps/Live%20Event%20Reminders/ler-child.groovy",
)

preferences {
    page name: "pageConfig"
    page name: "speechPushOptions", title: "", install:false, uninstall:false, nextPage: "pageConfig"
}

def pageConfig() {
    dynamicPage(name: "", title: "", install: true, uninstall: true) {
		display() 
        checkMapHandler()
        section("${getImage('instructions')} <b>Instructions:</b>", hideable: true, hidden: true) {
			paragraph "<b>Notes:</b>"
    		paragraph "Never miss an important Life Event again! Schedule reminders easily and locally."
		}

        section(getFormat("header-green", "${getImage("Blank")}"+" Data Device")) {
            createDeviceSection("Life Event Calendar Driver")
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Add to Calendar")) {
            if(state.calendarMap == null) state.calendarMap = [:]
            theMessage = ""
            input "theTitle", "text", title: "<b>Event Title</b>", width:6
            input "findRec", "bool", title: "<b>Find Record</b>", defaultValue:false, submitOnChange:true, width:6
            if(theTitle && findRec) {
                getRecord = state.calendarMap.get(theTitle)
                if(getRecord) {
                    theMessage = "<b><i> - Record Found - </i></b>"
                    if(logEnable) log.debug "In Add to Calendar - Record Found - $theTitle"
                    try{
                        (gDate, gTime1, gTime2, gEDate, gETime1, gETime2, gDesc, gRepeatMinutes, gRepeatMax, gDays, gYearly) = getRecord.split(";")
                        if(logEnable) log.debug "In Add to Calendar - $gDate, $gTime1, $gTime2, $gEDate, $gETime1, $gETime2, $gDesc, $gRepeatMinutes, $gRepeatMax, $gDays, $gYearly"
                        app.updateSetting("theDate", [value: gDate, type: "date"])
                        app.updateSetting("theTime", [value: gTime1, type: "time"])
                        app.updateSetting("endDate", [value: gEDate, type: "date"])
                        app.updateSetting("endTime", [value: gETime1, type: "time"])
                        app.updateSetting("theText", [value: gDesc, type: "text"])
                        app.updateSetting("msgRepeatMinutes", [value: gRepeatMinutes, type: "number"])
                        app.updateSetting("msgRepeatMax", [value: gRepeatMax, type: "number"])
                        if(gYearly == "T") { app.updateSetting("repeatYearly", [value: "true",type: "bool"]) }
                        app.updateSetting("repeatInDays", [value: gDays, type: "text"])
                    } catch(e) {
                        log.error "Life Event Calendar - Something seems to be wrong with the database: ${getRecord}"
                    }
                } else {
                    theMessage = "<b><i> - Record Not Found - Adding new record - </i></b>"
                    if(logEnable) log.debug "In Add to Calendar - Clearing the record"
                    app.removeSetting("theDate")
                    app.removeSetting("theTime")
                    app.removeSetting("endDate")
                    app.removeSetting("endTime")
                    app.removeSetting("theText")
                    app.removeSetting("msgRepeatMinutes")
                    app.removeSetting("msgRepeatMax")
                    app.removeSetting("repeatYearly")
                    app.removeSetting("repeatInDays")    
                }
                app.updateSetting("findRec", [value: "false",type: "bool"]) 
            }
            paragraph "<hr>"
            paragraph "${theMessage}"
            input "theDate", "date", title: "Event Start Date", width:6, submitOnChange:true
            input "theTime", "time", title: "Event Start Time", width:6, submitOnChange:true
            input "endDate", "date", title: "Event End Date", width:6, submitOnChange:true
            input "endTime", "time", title: "Event End Time", width:6, submitOnChange:true  
            input "theText", "text", title: "Event Description", submitOnChange:true

            input "msgRepeatMinutes", "number", title: "Repeat every XX minutes (optional)", width:6, submitOnChange:true
            input "msgRepeatMax", "number", title: "Max number of repeats (optional)", width:6, submitOnChange:true

            input "repeatYearly", "bool", title: "Repeat Yearly from start date (optional)", defaultValue:false, submitOnChange:true
            input "repeatInDays", "text", title: "Repeat Every X days from start date (optional)", required:false, submitOnChange:true

            paragraph "<small>* Remember to click outside any field before clicking on a button.</small>"

            input "bCancel", "button", title: "Cancel", width: 3
            input "bAdd", "button", title: "Add/Edit", width: 3
            input "bDel", "button", title: "Delete", width: 3
            input "bClear", "button", title: "Clear All", width: 3
            input "refreshPage", "bool", title: "Refresh Page", submitOnChange:true
            if(refreshPage) {
                app.updateSetting("refreshPage", [value: "false",type: "bool"])
            }
        }

        section() {
            paragraph "<hr>"
            if(state.calendarMap == null) {
                theMap = "No devices are setup"
            } else {
                if(logEnable) log.info "Making new Map display"
                theMap = "<table width=100%><tr><td><b>Title</b><td><b>S Date</b><td><b>S Time</b><td><b>E Date</b><td><b>E Time</b><td><b>Repeat<br>Every</b><td><b>Repeat<br>Max</b><td><b>Days</b><td><b>Year</b>"
                sortedMap = state.calendarMap.sort { a, b -> a.value <=> b.value }
                sortedMap.each { cm ->
                    mTitle = cm.key
                    try {
                        (mDate, mTime1, mTime2, mEDate, mETime1, mETime2, mDesc, mRepeatMinutes, mRepeatMax, mDays, mYearly) = cm.value.split(";")
                    } catch(e) {}
                    theMap += "<tr><td>$mTitle<td>$mDate<td>$mTime2<td>$mEDate<td>$mETime2<td>$mRepeatMinutes<td>$mRepeatMax<td>$mDays<td>$mYearly"
                    theMap += "<tr><td colspan=9> - <b>Description:</b> $mDesc"
                }
                theMap += "</table>"
            }
            paragraph "${theMap}"
            paragraph "<hr>"
        }
        
        section(getFormat("header-green", "${getImage("Blank")}"+" Notification Options")) {
            if(useSpeech || sendPushMessage) {
                href "speechPushOptions", title:"${getImage("checkMarkGreen")} Speech/Push Options", description:"Click here for options"
            } else {
                href "speechPushOptions", title:"Speech/Push Options", description:"Click here for options"
            }
            input "theSwitches", "capability.switch", title: "Additional Switches to Turn On", required:false, multiple:true, submitOnChange:true
            paragraph "<small>* The switches selected here will automatically turn on with the Event trigger and then turn off when the Event has finished.</small>"
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" Other Options")) {
            paragraph "Sometimes devices can miss commands due to HE's speed. This option will allow you to adjust the time between commands being sent."
            input "actionDelay", "number", title: "Delay (in milliseconds - 1000 = 1 second, 3 sec max)", range: '1..3000', defaultValue:actionDelayValue, required:false, submitOnChange:true
            input "updateTime", "time", title: "App has to check the calendar each morning, choose the Time to check", required:true, submitOnChange:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" App Control")) {
            input "pauseApp", "bool", title: "Pause App", defaultValue:false, submitOnChange:true
            if(pauseApp) {
                if(app.label) {
                    if(!app.label.contains("(Paused)")) {
                        app.updateLabel(app.label + " <span style='color:red'>(Paused)</span>")
                    }
                }
            } else {
                if(app.label) {
                    if(app.label.contains("(Paused)")) {
                        app.updateLabel(app.label - " <span style='color:red'>(Paused)</span>")
                    }
                }
            }
        }
        section() {
            paragraph "This app can be enabled/disabled by using a switch. The switch can also be used to enable/disable several apps at the same time."
            input "disableSwitch", "capability.switch", title: "Switch Device(s) to Enable / Disable this app", submitOnChange:true, required:false, multiple:true
        }

        section(getFormat("header-green", "${getImage("Blank")}"+" General")) {
            if(pauseApp) { 
                paragraph app.label
            } else {
                label title: "Enter a name for this automation", required:false
            }
            input "logEnable", "bool", title: "Enable Debug Options", description: "Log Options", defaultValue:false, submitOnChange:true
            if(logEnable) {
                input "logOffTime", "enum", title: "Logs Off Time", required:false, multiple:false, options: ["1 Hour", "2 Hours", "3 Hours", "4 Hours", "5 Hours", "Keep On"]
            }
        }
		display2()
	}
}

def speechPushOptions(){
    dynamicPage(name: "speechPushOptions", title: "", install: false, uninstall:false){
        display()
		section(getFormat("header-green", "${getImage("Blank")}"+" Speaker Options")) { 
           paragraph "All BPTWorld Apps use <a href='https://community.hubitat.com/t/release-follow-me-speaker-control-with-priority-messaging-volume-controls-voices-and-sound-files/12139' target=_blank>Follow Me</a> to process Notifications.  Please be sure to have Follow Me installed before trying to send any notifications."
            input "useSpeech", "bool", title: "Use Speech through Follow Me", defaultValue:false, submitOnChange:true
            if(useSpeech) input "fmSpeaker", "capability.speechSynthesis", title: "Select your Follow Me device", required:true, submitOnChange:true
        }
        section(getFormat("header-green", "${getImage("Blank")}"+" Push Messages")) {
            input "sendPushMessage", "capability.notification", title: "Send a Push notification?", multiple:true, required:false, submitOnChange:true
        }
        
        if(useSpeech || sendPushMessage) {
            wc = "<u>Optional wildcards:</u><br>"
            wc += "%title% - returns the Event Title<br>"
            wc += "%description% - returns the Event Description<br>"
            
            section(getFormat("header-green", "${getImage("Blank")}"+" Message Options")) {
                paragraph "${wc}"
                input "messages", "text", title: "Random Message - Separate each message with <b>;</b> (semicolon)", required:true, submitOnChange:true
                input "msgList", "bool", defaultValue: true, title: "Show a list view of the messages?", description: "List View", submitOnChange:true
                if(msgList) {
                    def values = "${messages}".split(";")
                    listMap = ""
                    values.each { item -> listMap += "${item}<br>"}
                    paragraph "${listMap}"
                }
            }
            
            section(getFormat("header-green", "${getImage("Blank")}"+" Repeat Notifications Control")) {
                paragraph "If using the Repeat option with any Event Reminder, please use the ${dataDevice} device as a control switch. This switch will automatically turn on when the Event triggers and back off again when the Event has finished. If you want the Event to finish early, manually turn this switch off."
            }
        }
        display2()
    }
}

def installed() {
    log.debug "Installed with settings: ${settings}"
	initialize()
}

def updated() {	
    if(logEnable) log.debug "Updated with settings: ${settings}"
	unschedule()
    unsubscribe()
    if(logEnable && logOffTime == "1 Hour") runIn(3600, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "2 Hours") runIn(7200, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "3 Hours") runIn(10800, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "4 Hours") runIn(14400, logsOff, [overwrite:false])
    if(logEnable && logOffTime == "5 Hours") runIn(18000, logsOff, [overwrite:false])
    if(logEnagle && logOffTime == "Keep On") unschedule(logsOff)
	initialize()
}

def initialize() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        state.oldSwitchValue = null
        state.numOfRepeats = 1
        dateTime = updateTime.split("T")
        (updateHour, updateMin) = dateTime[1].split(":")
        theSchedule = "0 ${updateMin} ${updateHour} * * ? *"
        schedule(theSchedule, nextHandler)
        
        scheduleHandler()
        nextHandler()
    }
}

def startTheProcess(data) {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(logEnable) log.debug "******************** Start - startTheProcess (${state.version}) ********************"
        if(logEnable) log.debug "In startTheProcess (${state.version}) - data: ${data}"
        (nTitle, nStatus) = data.split(";")
        state.calendarMap.each { cm ->
            theTitle = cm.key
            if(theTitle == nTitle) {
                pauseExecution(actionDelay ?: 100)
                if(nStatus == "on") {
                    dataDevice.on()
                } else {
                    dataDevice.off()
                }
                if(theSwitches) {
                    theSwitches.each { it ->
                        pauseExecution(actionDelay ?: 100)
                        if(nStatus == "on") {
                            it.on()
                        } else {
                            it.off()
                        }
                    }
                }

                if(nStatus == "off") {
                    state.oldSwitchValue = null
                    state.numOfRepeats = 1
                }

                try {
                    (theDate, theTime1, theTime2, eDate, eTime1, eTime2, theDesc, theRepeatMinutes, theRepeatMax, theDays, yearly) = cm.value.split(";")
                } catch(e) {}
                if(theDesc) { dataDevice.sendEvent(name: "currentEvent", value: theDesc, isStateChange: true) }
                if((useSpeech || sendPushMessage) && nStatus == "on") messageHandler(theTitle, theDesc)
            }
        }

        if(msgRepeat && nStatus == "on") {
            if(logEnable) log.debug "In startTheProcess - Repeat - numOfRepeats: ${state.numOfRepeats} - msgRepeatMax: ${theRepeatMax}"
            repeat = false
            if(state.numOfRepeats == null) state.numOfRepeats = 1
            if(state.numOfRepeats < msgRepeatMax) {
                if(state.numOfRepeats == 1) {
                    pauseExecution(actionDelay ?: 100)
                    dataDevice.on()
                }
                repeat = dataDevice.currentValue("switch")
                if(repeat == "on") {
                    if(logEnable) log.debug "In startTheProcess - repeat is ${repeat}"
                    rTime = (theRepeatMinutes.toInteger() * 60)
                    state.numOfRepeats += 1
                    if(logEnable) log.debug "In startTheProcess - Repeat - Running again in ${theRepeatMinutes} minutes (${rTime})"
                    runIn(rTime, startTheProcess, [data: theTitle]) 
                } else {
                    state.oldSwitchValue = null
                    state.numOfRepeats = 1
                }
            } else {
                pauseExecution(actionDelay ?: 100)
                dataDevice.off()
                dataDevice.sendEvent(name: "currentEvent", value: "-", isStateChange: true)
                if(theSwitches) {
                    theSwitches.each { it ->
                        pauseExecution(actionDelay ?: 100)
                        it.off()
                    }
                }
                state.oldSwitchValue = null
                state.numOfRepeats = 1
            }
        } else {
            if(logEnable) log.debug "In startTheProcess - No repeats today"
        }
        if(theDays != "-") { futureHandler(theTitle, theDate, theTime1, eDate, eTime1, theDays) }
        if(logEnable) log.debug "******************** End startTheProcess (${state.version}) ********************"
    }
}

def messageHandler(theTitle, theDesc) {
    if(logEnable) log.debug "In messageHandler (${state.version})"
    def mValues = "${messages}".split(";")
	mSize = mValues.size().toInteger()
    def randomKey = new Random().nextInt(mSize)
    state.message = mValues[randomKey]

    if(state.message.contains("%title%")) {state.message = state.message.replace('%title%', "${theTitle}")}
    if(state.message.contains("%description%")) {state.message = state.message.replace('%description%', "${theDesc}")}
    if(logEnable) log.debug "In messageHandler - message: ${state.message}"
    if(useSpeech) letsTalk(state.message)
    if(sendPushMessage) pushHandler(state.message)
}

def nextHandler() {
    if(logEnable) log.debug "In nextHandler (${state.version})"
    x = 1
    tDate = new Date()
    sortedMap = state.calendarMap.sort { a, b -> a.value <=> b.value }
    sortedMap.each { cm ->
        theTitle = cm.key
        try {
            (theDate, theTime1, theTime2, theDesc, theRepeatMinutes, theRepeatMax, theDays, yearly) = cm.value.split(";")
        } catch(e) {}
        (tYear, tMonth, tDay) = theDate.split("-")
        Date mDate = new Date("${tMonth}/${tDay}/${tYear}")
        if(mDate.after(tDate)) {
            if(x == 1) {
                nextEvent = "$theDate $theTime2 - $theDesc"
                nextThree = "$theDate $theTime2 - $theDesc<br>"
                dataDevice.sendEvent(name: "nextEvent", value: nextEvent, isStateChange: true)
            } else if(x <=3) {
                nextThree += "$theDate $theTime2 - $theDesc<br>"
                dataDevice.sendEvent(name: "nextThree", value: nextThree, isStateChange: true)
            }
            x += 1
        }
    }
}

def scheduleHandler() {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(logEnable) log.debug "In scheduleHandler (${state.version})"
        state.calendarMap.each { cm ->
            theTitle = cm.key
            try {
                (theDate, theTime1, theTime2, endDate, endTime1, endTime2, theDesc, theRepeatMinutes, theRepeatMax, theDays, yearly) = cm.value.split(";")
            } catch(e) {
                log.error e
            }
            (theYear, theMonth, theDay) = theDate.split("-")
            (theHour, theMin) = theTime1.split(":")

            (eYear, eMonth, eDay) = endDate.split("-")
            (eHour, eMin) = endTime1.split(":")

            Date checkDate = new Date("${theMonth}/${theDay}/${theYear} ${eHour}:${eMin}")
            Date now = new Date()
            if(logEnable) log.debug "In scheduleHandler - checking yearly: ${yearly}"
            if(yearly == "F") {    // Just THIS year
                if(logEnable) log.debug "In scheduleHandler - checking date: ${checkDate} is before ${now}"
                if(checkDate.after(now)) {          
                    startSchedule = "0 ${theMin} ${theHour} ${theDay} ${theMonth} ? ${theYear}"
                    endSchedule = "0 ${eMin} ${eHour} ${eDay} ${eMonth} ? ${eYear}"
                    if(logEnable) log.debug "In scheduleHandler - Setting schedule for START: ${theTitle}: 0 ${theMin} ${theHour} ${theDay} ${theMonth} ? ${theYear}"
                    if(logEnable) log.debug "In scheduleHandler - Setting schedule for END: ${theTitle}: 0 ${eMin} ${eHour} ${eDay} ${eMonth} ? ${eYear}"
                } else {
                    if(logEnable) log.debug "In scheduleHandler - Schedule was set for JUST this year and that date has passed. Skipping."
                }
            } else {               // Year after year after year
                startSchedule = "0 ${theMin} ${theHour} ${theDay} ${theMonth} ? *"
                endSchedule = "0 ${eMin} ${eHour} ${eDay} ${eMonth} ? *"
                if(logEnable) log.debug "In scheduleHandler - Setting schedule for START: ${theTitle}: 0 ${theMin} ${theHour} ${theDay} ${theMonth} ? *"
                if(logEnable) log.debug "In scheduleHandler - Setting schedule for END: ${theTitle}: 0 ${eMin} ${eHour} ${eDay} ${eMonth} ? *"
            }

            startStuff = "$theTitle;on"
            endStuff = "$theTitle;off"
            if(startSchedule && endSchedule) {
                schedule(startSchedule, startTheProcess, [data: startStuff, overwrite:false])
                schedule(endSchedule, startTheProcess, [data: endStuff, overwrite:false])
            }
        }
        if(logEnable) log.debug "In scheduleHandler - Finished setting up the schedule"
    }
}

def futureHandler(theTitle, theDate, theTime1, eDate, eTime1, theDays) {
    checkEnableHandler()
    if(pauseApp) {
        log.info "${app.label} is Paused"
    } else {
        if(logEnable) log.debug "In futureHandler (${state.version}) - theTitle: ${theTitle} - theDate: ${theDate} - theTime1: ${theTime1} - eDate: ${eDate} - eTime1: ${eTime1} - theDays: ${theDays}"
        hmd = theDays.toInteger()
        Date futureDate = new Date().plus(hmd)
        Date futureEndDate = new Date().plus(hmd)
        if(logEnable) log.debug "In futureHandler - theDays: ${theDays} - futureDate: ${futureDate} - futureEndDate: ${futureEndDate}"

        hmdMonth = futureDate.format("MM")
        hmdDay = futureDate.format("dd")
        hmdYear = futureDate.format("yyyy")
        (hmdHour, hmdMin) = theTime1.split(":")

        ehmdMonth = futureEndDate.format("MM")
        ehmdDay = futureEndDate.format("dd")
        ehmdYear = futureEndDate.format("yyyy")
        (ehmdHour, ehmdMin) = eTime1.split(":")

        hmdSchedule = "0 ${hmdMin} ${hmdHour} ${hmdDay} ${hmdMonth} ? ${hmdYear}"
        ehmdSchedule = "0 ${ehmdMin} ${ehmdHour} ${ehmdDay} ${ehmdMonth} ? ${ehmdYear}"
        if(logEnable) log.debug "In futureHandler - schedule START: 0 ${hmdMin} ${hmdHour} ${hmdDay} ${hmdMonth} ? ${hmdYear}"
        if(logEnable) log.debug "In futureHandler - schedule END: 0 ${ehmdMin} ${ehmdHour} ${ehmdDay} ${ehmdMonth} ? ${ehmdYear}"
        startStuff = "$theTitle;on"
        endStuff = "$theTitle;off"
        schedule(hmdSchedule, startTheProcess, [data: startStuff, overwrite:false])
        schedule(ehmdSchedule, startTheProcess, [data: endStuff, overwrite:false])
    }
}

def appButtonHandler(buttonPressed) {
    if(logEnable) log.debug "In appButtonHandler (${state.version}) - Button Pressed: ${buttonPressed}"
    if(state.calendarMap == null) state.calendarMap = [:]

    if(buttonPressed == "bDel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"       
        state.calendarMap.remove(theTitle)
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(buttonPressed == "bAdd") {
        
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"        
        if(logEnable) log.debug "In appButtonHandler - ADD - theDate: ${theDate} - theTime: ${theTime}"
        newDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss", theTime)
        String timePart1 = newDate.format("HH:mm")      // 24 h
        String timePart2 = newDate.format("hh:mm a")    // 12 h
        if(logEnable) log.debug "In appButtonHandler - timePart1: ${timePart1} - timePart2: ${timePart2}"
        if(endTime == null) {
            use( TimeCategory ) { newEndDate = newDate + 1.minutes }
        } else {
            newEndDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss", endTime)
        }
        String endTimePart1 = newEndDate.format("HH:mm")      // 24 h
        String endTimePart2 = newEndDate.format("hh:mm a")    // 12 h
        if(logEnable) log.debug "In appButtonHandler - endTimePart1: ${endTimePart1} - endTimePart2: ${endTimePart2}"
        if(endDate == null) endDate = theDate
        if(msgRepeatMinutes == null) msgRepeatMinutes = "-"
        if(msgRepeatMax == null) msgRepeatMax = "-"
        if(repeatInDays == null) repeatInDays = "-"
        if(theText == null || theText == "null") theText = "-"
        if(repeatYearly == null) repeatYearly = "F"
        if(repeatYearly == false) repeatYearly = "F"
        if(repeatYearly == true) repeatYearly = "T"
        
        if(logEnable) log.debug "In appButtonHandler - ${theDate} - ${timePart1} - ${timePart2} - ${endDate} - ${endTimePart1} - ${endTimePart2} - ${theText} - ${msgRepeatMinutes} - ${msgRepeatMax} - ${repeatInDays} - ${repeatYearly}"   
       //state.calendarMap.put(theTitle,"${theDate};${timePart1};${timePart2};${theText};${msgRepeatMinutes};${msgRepeatMax};${repeatInDays};${repeatYearly}")
        state.calendarMap.put(theTitle,"${theDate};${timePart1};${timePart2};${endDate};${endTimePart1};${endTimePart2};${theText};${msgRepeatMinutes};${msgRepeatMax};${repeatInDays};${repeatYearly}")
        if(logEnable) log.debug "In appButtonHandler - Finished Working"       
    } else if(buttonPressed == "bCancel") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    } else if(buttonPressed == "bClear") {
        if(logEnable) log.debug "In appButtonHandler - Working on: ${buttonPressed}"       
        state.calendarMap = [:]
        if(logEnable) log.debug "In appButtonHandler - Finished Working"
    }
}

def checkMapHandler() {
    if(logEnable) log.debug "In checkMapHandler (${state.version})" 
    if(state.calendarMap == null) state.calendarMap = [:]
    log.debug "calendarMap: ${state.calendarMap}"
    sortedMap = state.calendarMap.sort { a, b -> a.value <=> b.value }
    sortedMap.each { cm ->
        mTitle = cm.key
        if(logEnable) log.debug "In checkMapHandler - Checking Map line: ${cm.value}"
        (mDate, mTime1, mTime2, mDesc, mRepeatMinutes, mRepeatMax, mDays, mYearly) = cm.value.split(";")
        bulk = cm.value.split(";")
        bulkSize = bulk.size()
        if(logEnable) log.debug "In checkMapHandler - bulkSize: ${bulkSize}"
        if(bulkSize > 10) {
            if(logEnable) log.debug "In checkMapHandler - map is the right size, moving on."
            return
        } else {
            if(logEnable) log.debug "In checkMapHandler - Fixing Map"
            mEDate = mDate
            (tHour, tMin) = mTime1.split(":")
            neTime = tMin.toInteger() + 1
            newEndTime = "${tHour}:${neTime}" 
            endTime = "${mDate} ${newEndTime}"
            newEndDate = Date.parse("yyyy-MM-dd HH:mm", endTime)

            String mETime1 = newEndDate.format("HH:mm")      // 24 h
            String mETime2 = newEndDate.format("hh:mm a")    // 12 h
            if(logEnable) log.debug "In checkMapHandler - mEDate: ${mEDate} - mETime1: ${mETime1} - mETime2: ${mETime2}"
            
            mRepeatMinutes = "-"
            mRepeatMax = "-"
            mDays = "-"        
            if(mYearly == "") mYearly = "F"
            if(mYearly == false) mYearly = "F"
            if(mYearly == true) mYearly = "T"

            if(logEnable) log.debug "In checkMapHandler - ${mDate}; ${mTime1}; ${mTime2}; ${mEDate}; ${mETime1}; ${mETime2}; ${mDesc}; ${mRepeatMinutes}; ${mRepeatMax}; ${mDays}; ${mYearly}"   
            state.calendarMap.put(mTitle,"${mDate};${mTime1};${mTime2};${mEDate};${mETime1};${mETime2};${mDesc};${mRepeatMinutes};${mRepeatMax};${mDays};${mYearly}")
        }
    }   
}
